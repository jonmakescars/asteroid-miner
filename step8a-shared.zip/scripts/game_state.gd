class_name GameState
extends RefCounted
## The shared state of the running game, kept in static variables so that it survives switching
## between screens (scenes) and needs no autoload. Every screen reads and writes it directly:
## the game clock, the loaded body data, the ship and its mission plan.

const DATA_PATH := "res://data/bodies.json"
const DESIGN_PATH := "user://ship_design.json"  # written by the ship design screen
const DEFAULT_SHIP_DV_KMS := 10.0
const PARKING_ALTITUDE_KM := 400.0
const WARP_STEPS := [1.0 / 86400.0, 1.0 / 1440.0, 1.0 / 24.0, 1.0, 10.0, 100.0, 1000.0]  # game days per real second
const WARP_LABELS := ["real time", "1 min/s", "1 h/s", "1 day/s", "10 days/s", "100 days/s", "1000 days/s"]

# Body data (loaded once from bodies.json).
static var data_loaded := false
static var bodies: Dictionary = {}    # id -> body dictionary
static var children: Dictionary = {}  # id -> array of child ids
static var start_jd := 0.0

# Game clock.
static var initialized := false
static var time_jd := 0.0
static var paused := true
static var warp_index := 0

# The ship and its mission. legs: {parent, segment, t_start, label}; the first leg is the parking orbit.
static var legs: Array = []
static var plan: Dictionary = {}
static var message := ""
static var ship_name := "Ship"
static var ship_dv_kms := DEFAULT_SHIP_DV_KMS
static var ship_dv_source := "default value; design a ship on the ship design screen"

# Per-screen choices that are kept when switching screens.
static var mission_frame_index := 0
static var mission_target_index := 0


## Loads the body data once and makes sure the game has been started. Returns false if the data is missing.
static func load_data() -> bool:
	if not data_loaded:
		var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(DATA_PATH))
		if typeof(parsed) != TYPE_DICTIONARY:
			push_error("Cannot read %s (on Android, add *.json to the export filter)." % DATA_PATH)
			return false
		start_jd = float(parsed["game_start"]["jd"])
		bodies = {}
		children = {}
		for body in parsed["bodies"]:
			bodies[body["id"]] = body
			children[body["id"]] = []
		for id in bodies:
			var parent_id: Variant = bodies[id]["parent"]
			if parent_id != null:
				children[parent_id].append(id)
		data_loaded = true
	if not initialized:
		reset_mission()
	load_ship_design()
	return true


## Back to the start: time paused at the start date, the ship in a parking orbit around Earth, no plan.
static func reset_mission() -> void:
	initialized = true
	time_jd = start_jd
	paused = true
	warp_index = 0
	plan = {}
	message = ""
	var earth_gm := float(bodies["earth"]["gm_km3_s2"])
	var radius := float(bodies["earth"]["radius_km"]) + PARKING_ALTITUDE_KM
	var parking := TransferPlanner.circular_segment(radius, earth_gm, start_jd, 0.0)
	legs = [{"parent": "earth", "segment": parking, "t_start": start_jd, "label": "Parking orbit around Earth"}]


## Reads the name and delta-v of the ship from the ship design screen's saved design.
static func load_ship_design() -> void:
	if not FileAccess.file_exists(DESIGN_PATH):
		return
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(DESIGN_PATH))
	if typeof(parsed) == TYPE_DICTIONARY and parsed.has("total_dv_ms"):
		ship_dv_kms = float(parsed["total_dv_ms"]) / 1000.0
		ship_dv_source = "from the ship design screen"
		ship_name = str(parsed.get("name", ship_name))


# ---------------------------------------------------------------- clock

## Advances the game clock by delta real seconds. On arrival the time flow drops to real time.
static func advance(delta: float) -> void:
	if not paused:
		time_jd += delta * float(WARP_STEPS[warp_index])
	if not plan.is_empty() and plan["committed"] and not plan["arrival_seen"] and time_jd >= float(plan["t_arr"]):
		plan["arrival_seen"] = true
		warp_index = 0


## Faster: if paused, resumes at the selected rate; otherwise steps up one rate.
## Slower: if running at real time, pauses; otherwise steps down one rate (also while paused).
static func change_warp(step: int) -> void:
	if step > 0:
		if paused:
			paused = false
		else:
			warp_index = mini(warp_index + 1, WARP_STEPS.size() - 1)
	else:
		if not paused and warp_index == 0:
			paused = true
		else:
			warp_index = maxi(warp_index - 1, 0)


static func toggle_pause() -> void:
	paused = not paused


static func date_text(jd: float) -> String:
	return Time.get_datetime_string_from_unix_time(int((jd - 2440587.5) * 86400.0)).replace("T", " ")


# ---------------------------------------------------------------- positions on rails

## Position (km) of a body relative to its parent.
static func body_rel(id: String, jd: float) -> Vector2:
	var segments: Array = bodies[id]["orbit_segments"]
	if segments.is_empty():
		return Vector2.ZERO
	return Kepler.position_at(Kepler.segment_at(segments, jd), jd)


## Position (km) of a body relative to the Sun.
static func body_abs(id: String, jd: float) -> Vector2:
	var total := Vector2.ZERO
	var current: Variant = id
	while current != null:
		total += body_rel(str(current), jd)
		current = bodies[str(current)]["parent"]
	return total


static func leg_index_at(jd: float) -> int:
	var chosen := 0
	for i in legs.size():
		if float(legs[i]["t_start"]) <= jd:
			chosen = i
	return chosen


## Position (km) of the ship relative to the Sun.
static func ship_abs(jd: float) -> Vector2:
	var leg: Dictionary = legs[leg_index_at(jd)]
	return body_abs(str(leg["parent"]), jd) + Kepler.position_at(leg["segment"], jd)
