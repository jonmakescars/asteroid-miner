extends Control
## Prototype build step 5: design one ship with two chemical stages and see its delta-v.
## All widgets are built in code. Sliders for masses and thrust are logarithmic, so one
## slider covers small probes and large ships alike.

const ENGINES_PATH := "res://data/engines.json"
const DESIGN_PATH := "user://ship_design.json"  # read by the mission planner
const MOBILE_UI_SCALE := 2.5  # phone screens are dense; the UI is scaled up there only
const PAYLOAD_RANGE := Vector2(100.0, 500000.0)       # kg
const PROPELLANT_RANGE := Vector2(100.0, 2000000.0)   # kg
const SHIELD_RANGE := Vector2(0.0, 30.0)               # cm
const THRUST_RANGE := Vector2(1.0, 50000.0)           # kN

# Starting design: roughly a 10 km/s ship with a 5 t payload.
const DEFAULT_STAGES := [
	{"engine": "kerolox", "propellant": 100000.0, "thrust": 1500.0, "durability": 0.5},
	{"engine": "hydrolox", "propellant": 20000.0, "thrust": 110.0, "durability": 0.5},
]
const DEFAULT_PAYLOAD_KG := 5000.0

# Rough values from memory, only as a yardstick until the mission planner (step 6) calculates them.
const REFERENCE_DV := [
	["Earth orbit to Moon transfer", 3.1],
	["Moon orbit capture", 0.9],
	["Moon landing from low orbit", 1.8],
	["Earth orbit to Mars transfer", 3.6],
]

var engines: Dictionary = {}     # id -> engine dictionary
var engine_order: Array = []     # ids in file order
var rules: Dictionary = {}
var payload_ctl: Dictionary = {}
var stage_ctls: Array = []       # per stage: {"engine": OptionButton, "propellant": ctl, "thrust": ctl, "durability": ctl}
var ship_name := "Ship 1"
var start_payload_kg := DEFAULT_PAYLOAD_KG
var start_shield_cm := GameState.DEFAULT_SHIELD_CM
var shield_ctl: Dictionary = {}
var shield_area_m2 := 0.0
var shield_mass_kg := 0.0
var start_stages: Array = []     # starting values of the sliders (defaults, or the last saved design)
var result_label: Label
var scroll_box: ScrollContainer      # the scrolled screen
var margin_box: MarginContainer      # its margin; the bottom margin grows by the height of the on-screen keyboard
var keyboard_pad := -1               # the keyboard height (in screen units) that the bottom margin was made for
var last_focus: Control = null


func _ready() -> void:
	if OS.has_feature("mobile"):
		get_window().content_scale_factor = MOBILE_UI_SCALE
	if not _load_engines():
		return
	_apply_saved_design()
	_build_ui()
	_refresh()


func _load_engines() -> bool:
	var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(ENGINES_PATH))
	if typeof(parsed) != TYPE_DICTIONARY:
		push_error("Cannot read %s (on Android, add *.json to the export filter)." % ENGINES_PATH)
		return false
	rules = parsed["design_rules"]
	for engine in parsed["engines"]:
		engines[engine["id"]] = engine
		engine_order.append(engine["id"])
	return true


## Starts from the last saved design if there is one, so the design survives switching screens.
func _apply_saved_design() -> void:
	start_stages = DEFAULT_STAGES.duplicate(true)
	if not FileAccess.file_exists(DESIGN_PATH):
		return
	var saved: Variant = JSON.parse_string(FileAccess.get_file_as_string(DESIGN_PATH))
	if typeof(saved) != TYPE_DICTIONARY:
		return
	ship_name = str(saved.get("name", ship_name))
	start_payload_kg = clampf(float(saved.get("payload_kg", start_payload_kg)), PAYLOAD_RANGE.x, PAYLOAD_RANGE.y)
	start_shield_cm = clampf(float(saved.get("shield_cm", start_shield_cm)), 0.0, SHIELD_RANGE.y)
	var saved_stages: Variant = saved.get("stages", [])
	if typeof(saved_stages) != TYPE_ARRAY or saved_stages.size() != start_stages.size():
		return
	for i in start_stages.size():
		var stage: Dictionary = saved_stages[i]
		if not engines.has(str(stage.get("engine_id", ""))):
			continue
		start_stages[i] = {
			"engine": str(stage["engine_id"]),
			"propellant": clampf(float(stage["propellant_kg"]), PROPELLANT_RANGE.x, PROPELLANT_RANGE.y),
			"thrust": clampf(float(stage["thrust_kn"]), THRUST_RANGE.x, THRUST_RANGE.y),
			"durability": clampf(float(stage["durability"]), 0.0, 1.0),
		}


func _build_ui() -> void:
	var scroll := ScrollContainer.new()
	scroll_box = scroll
	scroll.set_anchors_preset(Control.PRESET_FULL_RECT)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(scroll)
	var margin := MarginContainer.new()
	margin_box = margin
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for side in ["left", "top", "right", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 16)
	scroll.add_child(margin)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	margin.add_child(box)

	var menu_button := Button.new()
	menu_button.text = "Menu"
	menu_button.custom_minimum_size = Vector2(0, 40)
	menu_button.pressed.connect(func() -> void: get_tree().change_scene_to_file("res://menu.tscn"))
	box.add_child(menu_button)
	var mission_button := Button.new()
	mission_button.text = "Orbit map"
	mission_button.custom_minimum_size = Vector2(0, 40)
	mission_button.pressed.connect(func() -> void: get_tree().change_scene_to_file("res://main.tscn"))
	box.add_child(mission_button)
	_add_heading(box, "Ship design (prototype step 5)")
	var name_row := HBoxContainer.new()
	box.add_child(name_row)
	var name_label := Label.new()
	name_label.text = "Ship name"
	name_label.custom_minimum_size = Vector2(60, 0)
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_row.add_child(name_label)
	var name_edit := LineEdit.new()
	name_edit.text = ship_name
	name_edit.custom_minimum_size = Vector2(180, 0)
	name_edit.max_length = 40
	name_edit.text_changed.connect(func(text: String) -> void:
		ship_name = text
		_refresh())
	name_row.add_child(name_edit)
	payload_ctl = _add_slider(box, "Payload", PAYLOAD_RANGE, true, start_payload_kg, "kg")
	shield_ctl = _add_slider(box, "Heat shield thickness", SHIELD_RANGE, false, start_shield_cm, "cm")

	for i in start_stages.size():
		var defaults: Dictionary = start_stages[i]
		_add_heading(box, "Stage %d%s" % [i + 1, " (fires first)" if i == 0 else ""])
		var picker := OptionButton.new()
		picker.custom_minimum_size = Vector2(0, 40)
		for id in engine_order:
			picker.add_item(str(engines[id]["name"]))
		picker.selected = engine_order.find(defaults["engine"])
		picker.item_selected.connect(func(_index: int) -> void: _refresh())
		box.add_child(picker)
		stage_ctls.append({
			"engine": picker,
			"propellant": _add_slider(box, "Propellant", PROPELLANT_RANGE, true, float(defaults["propellant"]), "kg"),
			"thrust": _add_slider(box, "Thrust", THRUST_RANGE, true, float(defaults["thrust"]), "kN"),
			"durability": _add_slider(box, "Durability", Vector2(0.0, 1.0), false, float(defaults["durability"]), ""),
		})

	_add_heading(box, "Result")
	result_label = Label.new()
	result_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART   # long lines wrap instead of making the screen wider than a portrait phone
	result_label.custom_minimum_size = Vector2(100, 0)
	result_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_child(result_label)


func _add_heading(parent: Control, text: String) -> void:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", 22)
	label.add_theme_color_override("font_color", Color(0.6, 0.8, 1.0))
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.custom_minimum_size = Vector2(100, 0)
	parent.add_child(Control.new())  # small spacer
	parent.add_child(label)


## Adds a row with a title, a text box and a unit, plus a slider; returns a Dictionary describing the control.
## The slider and the text box change the same value. The text box accepts exact numbers.
func _add_slider(parent: Control, title: String, value_range: Vector2, logarithmic: bool, start: float, unit: String) -> Dictionary:
	var row := HBoxContainer.new()
	parent.add_child(row)
	var title_label := Label.new()
	title_label.text = title
	title_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART   # a long title wraps (portrait is narrow)
	title_label.custom_minimum_size = Vector2(70, 0)
	title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(title_label)
	var edit := LineEdit.new()
	edit.custom_minimum_size = Vector2(110, 0)
	edit.alignment = HORIZONTAL_ALIGNMENT_RIGHT
	edit.select_all_on_focus = true
	edit.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER_DECIMAL
	row.add_child(edit)
	var unit_label := Label.new()
	unit_label.text = unit
	unit_label.custom_minimum_size = Vector2(36, 0)
	row.add_child(unit_label)

	var slider := HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.001
	slider.custom_minimum_size = Vector2(0, 40)
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	parent.add_child(slider)

	var control := {"edit": edit, "slider": slider, "range": value_range, "log": logarithmic, "value": start}
	slider.set_value_no_signal(_to_slider(start, control))
	slider.value_changed.connect(func(_v: float) -> void:
		control["value"] = _value_from_slider(control)
		_refresh())
	edit.text_submitted.connect(func(text: String) -> void: _apply_text(control, text))
	edit.focus_exited.connect(func() -> void: _apply_text(control, edit.text))
	return control


## Takes a number typed into a text box: clamps it to the allowed range and moves the slider to match.
func _apply_text(control: Dictionary, text: String) -> void:
	var cleaned := text.strip_edges().replace(",", ".")
	if cleaned.is_valid_float():
		var value_range: Vector2 = control["range"]
		var value := clampf(cleaned.to_float(), value_range.x, value_range.y)
		control["value"] = value
		(control["slider"] as HSlider).set_value_no_signal(_to_slider(value, control))
	_refresh()  # also rewrites the text box, which restores the old value if the input was not a number


func _to_slider(value: float, control: Dictionary) -> float:
	var value_range: Vector2 = control["range"]
	if control["log"]:
		return log(value / value_range.x) / log(value_range.y / value_range.x)
	return (value - value_range.x) / (value_range.y - value_range.x)


func _value_from_slider(control: Dictionary) -> float:
	var value_range: Vector2 = control["range"]
	var position: float = (control["slider"] as HSlider).value
	if control["log"]:
		var raw := value_range.x * pow(value_range.y / value_range.x, position)
		var step := pow(10.0, floor(log(raw) / log(10.0)) - 2.0)  # three significant figures
		return round(raw / step) * step
	return snappedf(value_range.x + position * (value_range.y - value_range.x), 0.01)


func _value_of(control: Dictionary) -> float:
	return float(control["value"])


func _num(value: float) -> String:
	if value >= 100.0:
		return str(int(round(value)))
	if value >= 10.0:
		return "%.1f" % value
	return "%.2f" % value


func _refresh() -> void:
	if result_label == null:
		return
	var payload_kg := _value_of(payload_ctl)
	_update_label(payload_ctl)
	var stages: Array = []
	for ctls in stage_ctls:
		for key in ["propellant", "thrust", "durability"]:
			_update_label(ctls[key])
		var picker: OptionButton = ctls["engine"]
		stages.append({
			"engine_id": engine_order[picker.selected],
			"propellant_kg": maxf(_value_of(ctls["propellant"]), float(rules["min_stage_propellant_kg"])),
			"thrust_kn": _value_of(ctls["thrust"]),
			"durability": _value_of(ctls["durability"]),
		})

	_update_label(shield_ctl)
	# The shield's area follows from the ship's size, which includes the shield: a few rounds settle it.
	var shield_cm := _value_of(shield_ctl)
	var bare_mass := float(ShipCalc.analyse(stages, engines, rules, payload_kg)["total_mass_kg"])
	shield_mass_kg = 0.0
	for _i in 4:
		shield_area_m2 = AeroBraking.area_for_mass(bare_mass + shield_mass_kg)
		shield_mass_kg = AeroBraking.shield_mass_kg(shield_cm, shield_area_m2)
	var analysis := ShipCalc.analyse(stages, engines, rules, payload_kg + shield_mass_kg)
	var lines: PackedStringArray = []
	# Without cargo only the shield rides on top of the stages; the payload slider is the cargo capacity.
	var empty_analysis := ShipCalc.analyse(stages, engines, rules, shield_mass_kg)
	lines.append("Delta-v without payload: %s km/s" % _num(float(empty_analysis["total_dv_ms"]) / 1000.0))
	lines.append("Delta-v with full payload (%s kg): %s km/s" % [
			_num(payload_kg), _num(float(analysis["total_dv_ms"]) / 1000.0)])
	lines.append("Total mass at launch: %s t" % _num(float(analysis["total_mass_kg"]) / 1000.0))
	lines.append("Heat shield: %s t over %s m2, takes %s MJ/m2 of heat (used for aerobraking at Earth and Mars)" % [
			_num(shield_mass_kg / 1000.0), _num(shield_area_m2), _num(AeroBraking.shield_capacity_mj_m2(shield_cm))])
	for i in stages.size():
		var result: Dictionary = analysis["stages"][i]
		var accel := float(result["accel_start_ms2"])
		lines.append("")
		lines.append("Stage %d: %s km/s | dry mass %s t | start mass %s t" % [
				i + 1, _num(float(result["dv_ms"]) / 1000.0), _num(float(result["dry_kg"]) / 1000.0),
				_num(float(result["mass_start_kg"]) / 1000.0)])
		lines.append("   start acceleration %s m/s2 (%s g) | burn time %s s" % [
				_num(accel), _num(accel / ShipCalc.G0), _num(float(result["burn_time_s"]))])
		if accel < float(rules["warn_start_accel_below_ms2"]):
			lines.append("   Warning: very low acceleration, the burn takes long (the instant-burn model is only approximate)")
		if accel / ShipCalc.G0 > float(rules["warn_start_accel_above_g"]):
			lines.append("   Warning: acceleration above %s g, dangerous for crew" % str(rules["warn_start_accel_above_g"]))
	lines.append("")
	lines.append("For comparison (approximate, from Earth orbit):")
	for reference in REFERENCE_DV:
		lines.append("   %s: %s km/s" % [reference[0], str(reference[1])])
	result_label.text = "\n".join(lines)
	_save_design(stages, payload_kg, analysis, empty_analysis)


func _update_label(control: Dictionary) -> void:
	(control["edit"] as LineEdit).text = String.num(_value_of(control), 2)


## The on-screen keyboard (phones) covers the lower part of the screen: the bottom margin grows by its height so the
## scrolled screen can move the edited text box above it, and the box in focus is scrolled into view (B-012).
func _process(_delta: float) -> void:
	if scroll_box == null:
		return
	var keyboard := int(ceil(float(DisplayServer.virtual_keyboard_get_height()) / maxf(get_window().content_scale_factor, 0.1)))
	var focused := get_viewport().gui_get_focus_owner()
	var edit_focus: Control = focused if focused is LineEdit else null
	if keyboard != keyboard_pad:
		keyboard_pad = keyboard
		margin_box.add_theme_constant_override("margin_bottom", 16 + keyboard)
		last_focus = null   # scroll to the box again with the new margin
	if edit_focus != last_focus:
		last_focus = edit_focus
		if edit_focus != null:
			_show_focused.call_deferred(edit_focus)


func _show_focused(control: Control) -> void:
	await get_tree().process_frame   # the new margin has to be laid out first
	if is_instance_valid(control) and control.is_inside_tree():
		scroll_box.ensure_control_visible(control)


## A click outside the focused text box ends the editing, which applies the typed value.
func _input(event: InputEvent) -> void:
	var click := event as InputEventMouseButton
	if click == null or not click.pressed:
		return
	var focused := get_viewport().gui_get_focus_owner()
	if focused is LineEdit and not focused.get_global_rect().has_point(click.global_position):
		focused.release_focus()


## Saves the current design so that the mission planner can use it. Besides the delta-v it stores the
## tank data of the equivalent single stage: total propellant, the average exhaust velocity weighted by
## propellant mass, and the dry mass that gives the same total delta-v (rocket equation).
func _save_design(stages: Array, payload_kg: float, analysis: Dictionary, empty_analysis: Dictionary) -> void:
	var file := FileAccess.open(DESIGN_PATH, FileAccess.WRITE)
	if file == null:
		return
	var propellant_kg := 0.0
	var momentum := 0.0
	for stage in stages:
		var stage_propellant := float(stage["propellant_kg"])
		propellant_kg += stage_propellant
		momentum += stage_propellant * float(engines[stage["engine_id"]]["isp_vac_s"]) * ShipCalc.G0
	var ve_eff := momentum / propellant_kg
	var total_dv_ms := float(analysis["total_dv_ms"])
	var dry_eff := propellant_kg / maxf(exp(total_dv_ms / ve_eff) - 1.0, 0.000001)
	# The same for the ship without cargo: the game adds the mass of the cargo it carries to this one.
	var dry_empty := propellant_kg / maxf(exp(float(empty_analysis["total_dv_ms"]) / ve_eff) - 1.0, 0.000001)
	file.store_string(JSON.stringify({
		"name": ship_name.strip_edges() if ship_name.strip_edges() != "" else "Unnamed ship",
		"payload_kg": payload_kg,
		"thrust_kn": float(stages[0]["thrust_kn"]) if not stages.is_empty() else 0.0,
		"shield_cm": _value_of(shield_ctl),
		"shield_area_m2": shield_area_m2,
		"shield_mass_kg": shield_mass_kg,
		"stages": stages,
		"total_dv_ms": total_dv_ms,
		"total_mass_kg": analysis["total_mass_kg"],
		"propellant_kg": propellant_kg,
		"ve_eff_ms": ve_eff,
		"dry_eff_kg": dry_eff,
		"dry_empty_kg": dry_empty,
		"empty_dv_ms": float(empty_analysis["total_dv_ms"]),
	}, "\t"))
