class_name AeroBraking
extends RefCounted
## Aerobraking: slowing a ship down in the upper atmosphere of a planet instead of with a burn.
##
## A pass is simulated numerically (RK4) through an exponential atmosphere, with drag from the ship's
## ballistic coefficient (mass / (drag coefficient x area)). Heating uses the Sutton-Graves relation
## (flux = k * sqrt(density / nose radius) * speed^3); the heat load is its integral over the pass.
## Several passes at the same periapsis altitude lower the apoapsis step by step. The small burns that
## would keep the periapsis altitude between passes are ignored in this first version.
##
## The aerobraking data of a plan lives in plan["aero"]; the mission planner calls setup_plan() once, and
## the orbit view calls apply() when the player changes the number of passes or the periapsis altitude.
## Units: km, km/s, km^3/s^2 for orbits; the pass simulation works in metres internally.

const SHIP_DENSITY_KG_M3 := 300.0        # average density, to get a ship's size from its mass
const DRAG_COEFFICIENT := 1.5
const AIM_RANGE_DEG := 20.0              # how far the arrival aim point can turn the periapsis for free (a little ahead or behind)
const SHIELD_KG_PER_M2_CM := 3.0         # shield mass per m2 of area and cm of thickness
const SHIELD_MJ_PER_M2_CM := 15.0        # heat load a shield can take per cm of thickness
const G_LIMIT := 10.0                    # peak deceleration limit for cargo-only ships (g)
const HEAT_MARGIN := 0.8                 # the planner uses at most this share of the shield's capacity
const MAX_PASSES := 64
const PASS_COUNTS := [1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64]   # tried in this order by the planner
const SEARCH_DT := 2.0                   # time step (s) for searching
const FINAL_DT := 1.0                    # time step (s) for the numbers that are shown
const INTERFACE_DENSITY := 1.0e-8        # the pass starts where the density is this small (kg/m3)
const G0 := 9.80665
const BAND_KM := 8.0                     # the periapsis slider covers this far above and below the setting

static var reserve_kms := 0.0   # (0.2.18) propellant kept back for a later stage of the route (the second stage of a plan via a planet), km/s
static var _acc := PackedFloat64Array([0.0, 0.0, 0.0])   # scratch: radial accel, tangential accel, drag accel


# ---------------------------------------------------------------- ship size and shield

## Frontal area (m2) of a ship of a given mass: a sphere of average density.
static func area_for_mass(mass_kg: float) -> float:
	var volume := mass_kg / SHIP_DENSITY_KG_M3
	var radius := pow(3.0 * volume / (4.0 * PI), 1.0 / 3.0)
	return PI * radius * radius


static func shield_mass_kg(thickness_cm: float, area_m2: float) -> float:
	return thickness_cm * SHIELD_KG_PER_M2_CM * area_m2


static func shield_capacity_mj_m2(thickness_cm: float) -> float:
	return thickness_cm * SHIELD_MJ_PER_M2_CM


## Altitude (km) where a pass starts.
static func interface_altitude_km(atmosphere: Dictionary) -> float:
	return float(atmosphere["scale_height_km"]) * log(float(atmosphere["surface_density_kg_m3"]) / INTERFACE_DENSITY)


# ---------------------------------------------------------------- one pass

## Accelerations for the state (r, radial speed, tangential speed), in m and m/s: fills _acc.
static func _accel(r: float, vr: float, vt: float, mu: float, radius: float, rho0: float, scale_h: float, beta: float) -> void:
	var v := sqrt(vr * vr + vt * vt)
	var rho := rho0 * exp(-(r - radius) / scale_h)
	var drag := rho * v * v / (2.0 * beta)
	_acc[0] = -mu / (r * r) + vt * vt / r - drag * vr / v
	_acc[1] = -vr * vt / r - drag * vt / v
	_acc[2] = drag


## One pass through the atmosphere. The orbit before the pass has the specific energy energy (km2/s2) and its
## periapsis at periapsis_altitude_km. Returns {"crash": true} if the ship hits the ground or cannot leave the
## atmosphere again (it slows down too much), otherwise
## {"energy", "heat_mj_m2", "peak_g", "peak_flux_mw_m2", "seconds"} with the energy after the pass.
static func simulate_pass(gm: float, radius_km: float, atmosphere: Dictionary, periapsis_altitude_km: float,
		energy: float, beta: float, nose_radius_m: float, dt: float) -> Dictionary:
	var mu := gm * 1.0e9
	var radius := radius_km * 1000.0
	var rho0 := float(atmosphere["surface_density_kg_m3"])
	var scale_h := float(atmosphere["scale_height_km"]) * 1000.0
	var r0 := radius + interface_altitude_km(atmosphere) * 1000.0
	var rp := radius + periapsis_altitude_km * 1000.0
	if rp >= r0:
		return {"energy": energy, "heat_mj_m2": 0.0, "peak_g": 0.0, "peak_flux_mw_m2": 0.0, "seconds": 0.0}
	var e_si := energy * 1.0e6
	var vp := sqrt(2.0 * (e_si + mu / rp))
	var ang_mom := rp * vp
	var v0 := sqrt(2.0 * (e_si + mu / r0))
	var vt := ang_mom / r0
	var vr := -sqrt(maxf(v0 * v0 - vt * vt, 0.0))
	var r := r0
	var heat := 0.0
	var peak_g := 0.0
	var peak_flux := 0.0
	var seconds := 0.0
	for _step in int(30000.0 / dt):
		_accel(r, vr, vt, mu, radius, rho0, scale_h, beta)
		var a1r := _acc[0]
		var a1t := _acc[1]
		peak_g = maxf(peak_g, _acc[2] / G0)
		var v := sqrt(vr * vr + vt * vt)
		var flux := 1.7415e-4 * sqrt(rho0 * exp(-(r - radius) / scale_h) / nose_radius_m) * v * v * v
		peak_flux = maxf(peak_flux, flux)
		heat += flux * dt
		var h2 := 0.5 * dt
		_accel(r + h2 * vr, vr + h2 * a1r, vt + h2 * a1t, mu, radius, rho0, scale_h, beta)
		var a2r := _acc[0]
		var a2t := _acc[1]
		var k2r := vr + h2 * a1r
		_accel(r + h2 * k2r, vr + h2 * a2r, vt + h2 * a2t, mu, radius, rho0, scale_h, beta)
		var a3r := _acc[0]
		var a3t := _acc[1]
		var k3r := vr + h2 * a2r
		_accel(r + dt * k3r, vr + dt * a3r, vt + dt * a3t, mu, radius, rho0, scale_h, beta)
		var a4r := _acc[0]
		var a4t := _acc[1]
		var k4r := vr + dt * a3r
		var new_r := r + dt / 6.0 * (vr + 2.0 * k2r + 2.0 * k3r + k4r)
		var new_vr := vr + dt / 6.0 * (a1r + 2.0 * a2r + 2.0 * a3r + a4r)
		var new_vt := vt + dt / 6.0 * (a1t + 2.0 * a2t + 2.0 * a3t + a4t)
		r = new_r
		vr = new_vr
		vt = new_vt
		seconds += dt
		if r < radius:
			return {"crash": true}
		if r >= r0 and vr > 0.0:
			break
	if r < r0:
		return {"crash": true}   # still in the atmosphere after the time limit: the ship cannot leave it
	var speed := sqrt(vr * vr + vt * vt)
	return {
		"energy": (0.5 * speed * speed - mu / r) / 1.0e6,
		"heat_mj_m2": heat / 1.0e6,
		"peak_g": peak_g,
		"peak_flux_mw_m2": peak_flux / 1.0e6,
		"seconds": seconds,
	}


## Apoapsis radius (km) of the orbit with the periapsis radius rp and the specific energy energy. A huge
## number means the ship still has escape energy; 0 means the orbit would be below the periapsis (too deep).
static func apoapsis_from_energy(gm: float, rp: float, energy: float) -> float:
	if energy >= 0.0:
		return 1.0e12
	var ra := 2.0 * (-gm / (2.0 * energy)) - rp
	return ra if ra >= rp else 0.0


# ---------------------------------------------------------------- several passes

## ctx: {gm, radius, atmosphere, ra_t (apoapsis radius of the target orbit, the goal of the passes), energy
## (before the first pass), beta, nose, shield_left_mj_m2, shield_capacity_mj_m2}.
## Runs n passes at the periapsis altitude h_km. Returns {"status", "heat", "peak_g", "peak_flux", "ras"
## (apoapsis after each pass, km), "seconds" (the time spent in the atmosphere), "ra"}. The status is "ok",
## "escape" (the ship is still too fast to be captured) or "too_slow" (the ship slows down so much that it
## cannot leave the atmosphere again, or crashes).
static func run_passes(ctx: Dictionary, h_km: float, n: int, dt: float) -> Dictionary:
	var gm := float(ctx["gm"])
	var rp := float(ctx["radius"]) + h_km
	var energy := float(ctx["energy"])
	var heat := 0.0
	var peak_g := 0.0
	var peak_flux := 0.0
	var seconds := 0.0
	var ras: Array = []
	var status := "ok"
	var ra := 1.0e12
	var budget := float(ctx.get("burn_budget_kms", 0.0))   # (B-044) propellant for burns right after a pass, km/s
	var assist := 0.0
	var burns: Array = []
	for _i in n:
		var pass_result := simulate_pass(gm, float(ctx["radius"]), ctx["atmosphere"], h_km, energy,
				float(ctx["beta"]), float(ctx["nose"]), dt)
		if pass_result.has("crash"):
			status = "too_slow"
			ra = 0.0
			break
		energy = float(pass_result["energy"])
		heat += float(pass_result["heat_mj_m2"])
		peak_g = maxf(peak_g, float(pass_result["peak_g"]))
		peak_flux = maxf(peak_flux, float(pass_result["peak_flux_mw_m2"]))
		seconds += float(pass_result["seconds"])
		ra = apoapsis_from_energy(gm, rp, energy)
		ras.append(ra)
		if ra <= 0.0:
			status = "too_slow"
			break
		if _i < n - 1 and ra >= float(ctx.get("soi_km", 1.0e11)):
			# B-044: the pass would throw the ship out of the space of the body. A short retrograde burn at the periapsis
			# (still at the exit of the atmosphere) lowers the apoapsis so that the next pass follows, if the tanks allow it.
			var cap_ra := maxf(0.25 * float(ctx.get("soi_km", 1.0e11)), float(ctx["ra_t"]))
			var v_now := sqrt(maxf(2.0 * (energy + gm / rp), 0.0))
			var energy_cap := -gm / (rp + cap_ra)
			var v_cap := sqrt(maxf(2.0 * (energy_cap + gm / rp), 0.0))
			var burn := v_now - v_cap
			if burn > 0.0 and burn <= budget - assist:
				assist += burn
				burns.append(burn)
				energy = energy_cap
				ra = cap_ra
				ras[ras.size() - 1] = cap_ra
			else:
				status = "escape"   # (the ship leaves the space of the body and never comes back for the next pass)
				break
	if status == "ok" and ra >= 1.0e11:
		status = "escape"
	return {"status": status, "heat": heat, "peak_g": peak_g, "peak_flux": peak_flux, "ras": ras,
			"seconds": seconds, "ra": ra, "energy": energy, "burn_dv": assist, "burns": burns}


## How far the result is from the goal: positive = the apoapsis is still above the target (braking missing),
## negative = the ship has slowed down too much.
static func _excess(result: Dictionary, ra_t: float) -> float:
	match str(result["status"]):
		"escape":
			return 1.0e12
		"too_slow":
			return -1.0
		_:
			return float(result["ra"]) - ra_t


## The periapsis altitude (km) at which n passes end with the apoapsis at (just above) the target apoapsis, or
## -1 if even the lowest allowed periapsis does not brake enough.
static func find_altitude(ctx: Dictionary, n: int, dt: float) -> float:
	var atmosphere: Dictionary = ctx["atmosphere"]
	var low := float(atmosphere["min_periapsis_altitude_km"])
	var high := interface_altitude_km(atmosphere) - 1.0
	var ra_t := float(ctx["ra_t"])
	if _excess(run_passes(ctx, low, n, dt), ra_t) > 0.0:
		return -1.0
	for _i in 12:
		var middle := 0.5 * (low + high)
		if _excess(run_passes(ctx, middle, n, dt), ra_t) > 0.0:
			high = middle
		else:
			low = middle
	return high


## The planner's suggestion: the fewest passes that stay within the shield's heat budget and the g limit.
## Heat grows with the number of passes while the g load falls, so the search stops at the first count that
## works, or gives up when the heat budget is already exceeded. Returns {"n", "h_km"} or {} if there is none.
static func suggest(ctx: Dictionary) -> Dictionary:
	var allowed := HEAT_MARGIN * float(ctx["shield_left_mj_m2"])
	for n_value in PASS_COUNTS:
		var n: int = n_value
		var h := find_altitude(ctx, n, SEARCH_DT)
		if h < 0.0:
			continue
		var result := run_passes(ctx, h, n, SEARCH_DT)
		if str(result["status"]) != "ok":
			continue
		if float(result["heat"]) > allowed:
			return {}
		if float(result["peak_g"]) <= G_LIMIT:
			return {"n": n, "h_km": h}
	return {}


# ---------------------------------------------------------------- burns after the passes

## Speed at the apoapsis (radius r2) of the ellipse with the periapsis radius r1 and the apoapsis radius r2.
static func _speed_at_apoapsis(gm: float, r1: float, r2: float) -> float:
	return sqrt(2.0 * gm * r1 / (r2 * (r1 + r2)))


## Speed at the periapsis (radius r1) of the same ellipse.
static func _speed_at_periapsis(gm: float, r1: float, r2: float) -> float:
	return sqrt(2.0 * gm * r2 / (r1 * (r1 + r2)))


## Delta-v (km/s) from the orbit after the passes (periapsis rp in the atmosphere, apoapsis ra) to the target
## orbit (rp_t, ra_t). If ra reaches rp_t: raise the periapsis to rp_t at the apoapsis, then move the apoapsis
## to ra_t at the new periapsis. Otherwise first raise the apoapsis to ra_t at the periapsis, then the
## periapsis at the new apoapsis.
## True if the apoapsis is set to the target apoapsis with a burn right after the last pass (at the periapsis),
## and the periapsis raised half an orbit later at the new apoapsis. That is the case when the passes leave the
## apoapsis below the target periapsis, or above the target apoapsis: the ship does not coast out to a far
## apoapsis and come back first.
static func burns_at_once(ra: float, rp_t: float, ra_t: float) -> bool:
	return ra < rp_t or ra > ra_t * 1.005


static func final_dv(gm: float, rp: float, ra: float, rp_t: float, ra_t: float) -> float:
	if not burns_at_once(ra, rp_t, ra_t):
		var raise_periapsis := absf(_speed_at_apoapsis(gm, rp_t, ra) - _speed_at_apoapsis(gm, rp, ra))
		var move_apoapsis := absf(_speed_at_periapsis(gm, rp_t, ra_t) - _speed_at_periapsis(gm, rp_t, ra))
		return raise_periapsis + move_apoapsis
	var raise_apoapsis := absf(_speed_at_periapsis(gm, rp, ra_t) - _speed_at_periapsis(gm, rp, ra))
	var raise_periapsis_later := absf(_speed_at_apoapsis(gm, rp_t, ra_t) - _speed_at_apoapsis(gm, rp, ra_t))
	return raise_apoapsis + raise_periapsis_later


## Delta-v (km/s) of the burns that capture a ship that leaves the last aerobraking pass still too fast (specific
## energy energy_after, km2/s2, above zero): at the periapsis right after the pass the apoapsis is set to the target
## apoapsis, and half an orbit later the periapsis is raised to the target periapsis.
static func escape_capture_dv(gm: float, rp: float, energy_after: float, rp_t: float, ra_t: float) -> float:
	var exit_speed := sqrt(maxf(2.0 * (energy_after + gm / rp), 0.0))
	var set_apoapsis := absf(_speed_at_periapsis(gm, rp, ra_t) - exit_speed)
	var raise_periapsis_later := absf(_speed_at_apoapsis(gm, rp_t, ra_t) - _speed_at_apoapsis(gm, rp, ra_t))
	return set_apoapsis + raise_periapsis_later


static func _period_days(gm: float, a_km: float) -> float:
	return TAU * sqrt(a_km * a_km * a_km / gm) / 86400.0


## direction: 1 counter-clockwise, -1 clockwise. mean_anomaly_deg counts in the direction of travel; a clockwise segment
## stores it (and the mean motion) with the opposite sign (see Kepler.direction).
static func _ellipse(gm: float, rp: float, ra: float, epoch_jd: float, axis_deg: float, mean_anomaly_deg: float, direction := 1) -> Dictionary:
	var a := 0.5 * (rp + ra)
	return {
		"epoch_jd": epoch_jd,
		"semi_major_axis_km": a,
		"eccentricity": (ra - rp) / (ra + rp),
		"longitude_of_ascending_node_deg": 0.0,
		"argument_of_periapsis_deg": axis_deg,
		"mean_anomaly_deg": mean_anomaly_deg * float(direction),
		"mean_motion_deg_per_day": TransferPlanner.mean_motion_deg_per_day(gm, a) * float(direction),
	}


## The direction of the orbit the plan ends in: 1 counter-clockwise, -1 clockwise.
static func orbit_dir(plan: Dictionary) -> int:
	return -1 if int(plan.get("orbit_dir", 1)) < 0 else 1


# ---------------------------------------------------------------- the plan's aerobraking data

## An orbit change at the body the ship is at (MissionPlanner._plan_orbit_change) can come in two variants: two propulsive
## burns, or a burn at the apoapsis that lowers the periapsis into the atmosphere followed by aerobraking passes. The plan
## holds both in plan["orbit_variants"] ({"propulsive": {...}, "aero": {...}}, the fields below) and switches the fields of
## the one in use into the plan itself, so that all the other code sees an ordinary plan.
const VARIANT_KEYS := ["t_dep", "t_arr", "flight_days", "dv_departure", "transfer_segment", "arrival_energy",
		"capture_phase_deg", "dv_capture", "capture_anomaly"]


## The aerobraking variant of an orbit change: the burn at the apoapsis of the current orbit (rp, ra) lowers the periapsis
## to altitude h_km, where the passes happen half an orbit later. If the target orbit runs the other way round, the ship is
## turned round at that burn (the speeds add up). inputs: gm, radius, rp, ra, rp_t, ra_t, t_burn, axis, old_dir, new_dir.
static func orbit_aero_variant(inputs: Dictionary, h_km: float) -> Dictionary:
	var gm := float(inputs["gm"])
	var rp := float(inputs["rp"])
	var ra := float(inputs["ra"])
	var rp_mid := float(inputs["radius"]) + h_km
	var t_burn := float(inputs["t_burn"])
	var before := _speed_at_apoapsis(gm, rp, ra)
	var after := _speed_at_apoapsis(gm, rp_mid, ra)
	var dv := before + after if int(inputs["new_dir"]) != int(inputs["old_dir"]) else absf(after - before)
	var half_days := _period_days(gm, 0.5 * (rp_mid + ra)) * 0.5
	return {
		"t_dep": t_burn,
		"t_arr": t_burn + half_days,
		"flight_days": half_days,
		"dv_departure": dv,
		"transfer_segment": _ellipse(gm, rp_mid, ra, t_burn, float(inputs["axis"]), 180.0, int(inputs["new_dir"])),
		"arrival_energy": -gm / (rp_mid + ra),
		"capture_phase_deg": float(inputs["axis"]),
		"dv_capture": final_dv(gm, rp_mid, ra, float(inputs["rp_t"]), float(inputs["ra_t"])),
		"capture_anomaly": 0.0,
	}


static func select_orbit_variant(plan: Dictionary, with_aerobraking: bool, h_km := -1.0) -> void:
	if not plan.has("orbit_variants"):
		return
	var variants: Dictionary = plan["orbit_variants"]
	if with_aerobraking and h_km > 0.0:
		variants["aero"] = orbit_aero_variant(variants["aero_inputs"], h_km)   # (the periapsis the burn sets is the one of the passes)
	var chosen: Dictionary = variants["aero"] if with_aerobraking else variants["propulsive"]
	for key in VARIANT_KEYS:
		var value = chosen[key]
		plan[key] = (value as Dictionary).duplicate(true) if value is Dictionary else value
	plan["aero_variant"] = with_aerobraking


## Prepares plan["aero"] for a plan made by MissionPlanner (which provides rp_t, ra_t, offset_deg,
## arrival_energy, capture_phase_deg, gm_target and dv_capture) and switches the suggestion on if there is one.
static func setup_plan(plan: Dictionary) -> void:
	var target: Dictionary = GameState.bodies[plan["target_id"]]
	var aero := {"available": false, "enabled": false, "outcome": "ok", "message": ""}
	plan["aero"] = aero
	select_orbit_variant(plan, false)   # (the propulsive orbit change, if this is an orbit change)
	_use_propulsive_capture(plan)
	if not (target.get("atmosphere") is Dictionary):
		return
	if GameState.ship_shield_cm <= 0.0:
		aero["message"] = "No heat shield: aerobraking is not possible."
		return
	var atmosphere: Dictionary = target["atmosphere"]
	var area := GameState.ship_shield_area_m2
	# The numbers of the aerobraking variant (an orbit change has its own departure and arrival for it), else the plan's own.
	var work := plan
	if plan.has("orbit_variants"):
		work = plan.duplicate()
		var variant: Dictionary = plan["orbit_variants"]["aero"]
		for key in VARIANT_KEYS:
			work[key] = variant[key]
	var propulsive_total := float(plan["dv_departure"]) + float(plan["dv_arrival"])   # (an orbit change is compared as a whole)
	var mass := GameState.ship_mass_after_departure(float(work["dv_departure"]))
	var ctx := {
		"gm": float(plan["gm_target"]), "radius": float(target["radius_km"]), "atmosphere": atmosphere,
		"ra_t": float(plan["ra_t"]), "energy": float(work["arrival_energy"]),
		"soi_km": GameState.context_radius_km(str(plan["target_id"]), float(work["t_arr"])),
		"burn_budget_kms": maxf(0.0, _dv_available() - float(work["dv_departure"])),
		"beta": mass / (DRAG_COEFFICIENT * area), "nose": sqrt(area / PI),
		"shield_left_mj_m2": GameState.shield_left_mj_m2(),
		"shield_capacity_mj_m2": shield_capacity_mj_m2(GameState.ship_shield_cm),
	}
	aero["available"] = true
	aero["ctx"] = ctx
	aero["h_min_km"] = float(atmosphere["min_periapsis_altitude_km"])
	aero["h_max_km"] = interface_altitude_km(atmosphere) - 1.0
	if float(work["arrival_energy"]) <= -float(plan["gm_target"]) / (float(plan["rp_t"]) + float(plan["ra_t"])):
		# B-037: the arrival orbit has less energy than the target orbit (for example from a moon up to a higher orbit round
		# its planet): aerobraking only takes energy away, so there is nothing for it to do.
		aero["n"] = 1
		aero["h_km"] = maxf(find_altitude(ctx, 1, SEARCH_DT), float(aero["h_min_km"]))
		center_band(aero, float(aero["h_km"]))
		aero["message"] = "The target orbit has more energy than the orbit the ship arrives on, so aerobraking cannot help here and the capture is propulsive. You can still switch aerobraking on."
		aero["off_reason"] = aero["message"]
		return
	var suggestion := suggest(ctx)
	if suggestion.is_empty():
		aero["n"] = 1
		aero["h_km"] = maxf(find_altitude(ctx, 1, SEARCH_DT), float(aero["h_min_km"]))
		center_band(aero, float(aero["h_km"]))
		aero["message"] = "The shield cannot take the heat of aerobraking with the safe margin the planner keeps (%.0f%% of the remaining shield in reserve), so the capture is propulsive. You can still switch aerobraking on." % ((1.0 - HEAT_MARGIN) * 100.0)
		aero["off_reason"] = aero["message"]
		return
	var propulsive_dv := float(plan["dv_capture"]) + axis_turn_dv(plan)   # (the propulsive capture; the plan itself may be a fly-by without it)
	apply(plan, true, int(suggestion["n"]), float(suggestion["h_km"]), true)
	var not_cheaper := float(plan["dv_arrival"]) >= propulsive_dv - 1.0e-6
	if plan.has("orbit_variants"):
		not_cheaper = float(plan["dv_departure"]) + float(plan["dv_arrival"]) >= propulsive_total - 1.0e-6
	if bool(aero["enabled"]) and str(aero["outcome"]) == "ok" and not_cheaper:
		# B-037: suggested only when it is cheaper than the purely propulsive plan.
		apply(plan, false, int(suggestion["n"]), float(suggestion["h_km"]), true)
		aero["message"] = "Aerobraking would not save any propellant here, so the capture is propulsive. You can still switch aerobraking on."
		aero["off_reason"] = aero["message"]


## Centres the range of the periapsis slider on altitude h_km.
static func center_band(aero: Dictionary, h_km: float) -> void:
	aero["band_lo"] = maxf(float(aero["h_min_km"]), h_km - BAND_KM)
	aero["band_hi"] = minf(float(aero["h_max_km"]), h_km + BAND_KM)


## Checks the target orbit itself: sets plan["outcome"] ("ok", "crash" or "burn_up"), plan["outcome_text"]
## (what will happen) and plan["warning"] (something to know that does not destroy the ship).
static func _set_target_outcome(plan: Dictionary) -> void:
	var target: Dictionary = GameState.bodies[plan["target_id"]]
	var rp_alt := float(plan["rp_t"]) - float(target["radius_km"])
	plan["outcome"] = "ok"
	plan["outcome_text"] = ""
	plan["warning"] = ""
	if rp_alt <= 0.0:
		plan["outcome"] = "crash"
		plan["outcome_text"] = "The periapsis of the target orbit (%.1f %s) is at or below the surface: the ship will crash into the surface of %s and be lost." % [UnitFormat.length(rp_alt), UnitFormat.length_unit(), target["name"]]
	elif target.get("atmosphere") is Dictionary:
		var atmosphere: Dictionary = target["atmosphere"]
		if rp_alt < float(atmosphere["min_periapsis_altitude_km"]):
			plan["outcome"] = "burn_up"
			plan["outcome_text"] = "The periapsis of the target orbit (%.1f %s) is deep inside the atmosphere of %s (below %.0f %s): the ship will burn up." % [UnitFormat.length(rp_alt), UnitFormat.length_unit(), target["name"], UnitFormat.length(float(atmosphere["min_periapsis_altitude_km"])), UnitFormat.length_unit()]
			var burn_aero: Dictionary = plan.get("aero", {})
			if burn_aero.has("shield_after"):
				burn_aero["shield_after"] = 0.0   # the ship burns up: nothing is left of the shield
		elif rp_alt < interface_altitude_km(atmosphere):
			plan["warning"] = "The periapsis of the target orbit (%.1f %s) is inside the upper atmosphere of %s (below %.0f %s): the orbit will decay." % [UnitFormat.length(rp_alt), UnitFormat.length_unit(), target["name"], UnitFormat.length(interface_altitude_km(atmosphere)), UnitFormat.length_unit()]


## The angle of the axis of the target orbit. It is universal: measured in the frame of the whole solar system
## (counter-clockwise from the right-hand direction), the same for every body, so that ships arriving at different
## times or from different directions can be planned into the same orbit. A circular orbit has no axis, so it
## simply continues from the arrival.
static func _axis_deg(plan: Dictionary) -> float:
	if OrbitControl.is_circular(float(plan["rp_t"]), float(plan["ra_t"])):
		return float(plan["capture_phase_deg"])
	return float(plan["offset_deg"])


## The angle (degrees, -180 to 180) from the natural direction of the periapsis of the arrival to the axis of the
## target orbit.
static func _axis_gap_deg(plan: Dictionary) -> float:
	if OrbitControl.is_circular(float(plan["rp_t"]), float(plan["ra_t"])):
		return 0.0
	return wrapf(_axis_deg(plan) - float(plan["capture_phase_deg"]), -180.0, 180.0)


## The direction of the periapsis of the orbit the ship arrives on (and of the aerobraking passes). When the
## arrival can be aimed (arriving from outside the sphere of influence) the aim point is shifted a little ahead or
## behind, which turns the periapsis by up to AIM_RANGE_DEG towards the axis of the target orbit at no cost. A
## transfer to the central body cannot be aimed: it arrives where it arrives.
static func _arrival_axis(plan: Dictionary) -> float:
	var phase := float(plan["capture_phase_deg"])
	if not bool(plan["aimable"]):
		return phase
	return phase + clampf(_axis_gap_deg(plan), -AIM_RANGE_DEG, AIM_RANGE_DEG)


## What is left of the angle between the arrival orbit and the target orbit after aiming (degrees, 0 to 180).
static func axis_turn_deg(plan: Dictionary) -> float:
	return absf(wrapf(_axis_deg(plan) - _arrival_axis(plan), -180.0, 180.0))


## Delta-v (km/s) for turning the axis of the arrival orbit to the axis of the target orbit by the angle that
## aiming could not cover: zero if there is nothing left or the orbit is circular, otherwise a burn at the crossing
## point of the two ellipses.
static func axis_turn_dv(plan: Dictionary) -> float:
	if OrbitControl.is_circular(float(plan["rp_t"]), float(plan["ra_t"])):
		return 0.0
	var rp := float(plan["rp_t"])
	var ra := float(plan["ra_t"])
	var e := (ra - rp) / (ra + rp)
	var p := 2.0 * rp * ra / (rp + ra)
	return 2.0 * e * sqrt(float(plan["gm_target"]) / p) * absf(sin(deg_to_rad(axis_turn_deg(plan)) * 0.5))


## Mean anomaly (degrees, 0 to 360) of the point with the true anomaly nu_deg on an orbit with the eccentricity e.
static func _mean_anomaly_deg(e: float, nu_deg: float) -> float:
	var nu := deg_to_rad(nu_deg)
	var ecc := 2.0 * atan2(sqrt(1.0 - e) * sin(nu * 0.5), sqrt(1.0 + e) * cos(nu * 0.5))
	return fposmod(rad_to_deg(ecc - e * sin(ecc)), 360.0)


## The ship is on the target-shaped orbit at the arrival axis, at the time t and the mean anomaly m0_deg. Two such
## orbits with different axes cross at two points on the line that bisects the axes, and at a crossing the ship has
## the same position and speed on both: only its radial speed changes sign, so a radial burn turns the axis without
## moving the ship. This adds the leg of the target orbit (at the universal axis) starting at the first crossing the
## ship reaches, and returns the time of that burn.
static func _append_turn_leg(legs: Array, plan: Dictionary, t: float, m0_deg: float) -> float:
	var gm := float(plan["gm_target"])
	var rp_t := float(plan["rp_t"])
	var ra_t := float(plan["ra_t"])
	var e := (ra_t - rp_t) / (ra_t + rp_t)
	var turn := wrapf(_axis_deg(plan) - _arrival_axis(plan), -180.0, 180.0)   # (positive: counter-clockwise)
	var n_deg_day := TransferPlanner.mean_motion_deg_per_day(gm, 0.5 * (rp_t + ra_t))
	var way := float(orbit_dir(plan))   # (the true anomaly counts in the direction of travel: against the angles on the screen for a clockwise orbit)
	var best_dt := INF
	var best_nu2 := 0.0
	for nu1 in [way * turn * 0.5, way * turn * 0.5 + 180.0]:   # true anomaly on the old orbit at the two crossings
		var dt := fposmod(_mean_anomaly_deg(e, nu1) - m0_deg, 360.0) / n_deg_day
		if dt < best_dt:
			best_dt = dt
			best_nu2 = nu1 - way * turn   # (the same point seen from the new orbit)
	var t_turn := t + best_dt
	legs.append({"parent": plan["target_id"],
			"segment": _ellipse(gm, rp_t, ra_t, t_turn, _axis_deg(plan), _mean_anomaly_deg(e, best_nu2), orbit_dir(plan)),
			"t_start": t_turn, "label": "Orbit around %s" % plan["target_name"], "kind": "orbit", "axis_turn": true})
	return t_turn


## Falls back to the propulsive capture burn at the target orbit.
static func _use_propulsive_capture(plan: Dictionary) -> void:
	plan["dv_arrival"] = float(plan["dv_capture"]) + axis_turn_dv(plan)
	plan["t_end"] = float(plan["t_arr"])
	var gm_t := float(plan["gm_target"])
	var rp_t := float(plan["rp_t"])
	var ra_t := float(plan["ra_t"])
	if axis_turn_deg(plan) > 0.5:
		# The ship is captured on the orbit it can reach (axis aimed as far as possible) and coasts to the point where
		# that orbit crosses the target orbit. There a radial burn turns the axis (part of dv_arrival): the ship
		# stays where it is and only the orbit changes.
		var legs: Array = [{
			"parent": plan["target_id"],
			"segment": _ellipse(gm_t, rp_t, ra_t, float(plan["t_arr"]), _arrival_axis(plan), float(plan.get("capture_anomaly", 0.0)), orbit_dir(plan)),
			"t_start": float(plan["t_arr"]),
			"label": "Capture orbit around %s" % plan["target_name"],
			"kind": "aero",
		}]
		plan["t_end"] = _append_turn_leg(legs, plan, float(plan["t_arr"]), float(plan.get("capture_anomaly", 0.0)))
		plan["capture_legs"] = legs
	else:
		plan["capture_legs"] = [{
			"parent": plan["target_id"],
			"segment": _ellipse(gm_t, rp_t, ra_t, float(plan["t_arr"]), _axis_deg(plan), float(plan.get("capture_anomaly", 0.0)), orbit_dir(plan)),
			"t_start": float(plan["t_arr"]),
			"label": "Orbit around %s" % plan["target_name"],
			"kind": "orbit",
		}]
	plan["flyby_propulsive"] = false
	_set_target_outcome(plan)
	_make_propulsive_flyby(plan)


## Step 4 (B-013): a ship with the propellant for the departure burn, but not for the capture burn, can still go.
## It flies past the target on a hyperbola (periapsis at the target orbit's periapsis) and stays on its orbit around
## the Sun. The capture burn is not counted any more, and the plan says so.
static func _make_propulsive_flyby(plan: Dictionary) -> void:
	if str(plan.get("outcome", "ok")) != "ok" or plan.get("orbit_change", false) or plan.get("committed", false):
		return
	if not plan.has("arrival_energy") or float(plan["arrival_energy"]) <= 0.0 or str(plan.get("frame", "")) == str(plan["target_id"]):
		return
	var left := GameState.dv_left_kms()
	var dep := float(plan["dv_departure"])
	if dep > left + 0.00001 or dep + float(plan["dv_arrival"]) <= left + 0.00001:
		return
	plan["flyby_propulsive"] = true
	plan["outcome"] = "flyby"
	plan["outcome_text"] = "Not enough propellant for the capture burn at %s (%.0f %s needed, %.0f %s left after the departure): the ship will fly past and stay on its orbit around the Sun." % [
			plan["target_name"], UnitFormat.speed_ms(float(plan["dv_arrival"]) * 1000.0), UnitFormat.speed_ms_unit(),
			UnitFormat.speed_ms((left - dep) * 1000.0), UnitFormat.speed_ms_unit()]
	plan["warning"] = str(plan["outcome_text"])
	plan["dv_arrival"] = 0.0
	plan["capture_legs"] = []
	plan["t_end"] = float(plan["t_arr"])


## Switches aerobraking on or off, or changes its passes and periapsis altitude, and recomputes the results,
## the orbit legs after arrival, the final burns and the end time of the capture. recenter moves the range
## of the periapsis slider to h_km (this also happens when h_km is outside of it).
static func apply(plan: Dictionary, enabled: bool, n: int, h_km: float, recenter := false) -> void:
	var aero: Dictionary = plan["aero"]
	select_orbit_variant(plan, enabled and bool(aero["available"]), h_km)   # (only for an orbit change)
	if plan.get("flyby_propulsive", false):
		plan["flyby_propulsive"] = false   # (decided again below, or by _use_propulsive_capture)
		plan["outcome"] = "ok"
		plan["outcome_text"] = ""
		plan["warning"] = ""
	aero["n"] = n
	aero["h_km"] = h_km
	if aero["available"] and (recenter or not aero.has("band_lo") or h_km < float(aero["band_lo"]) or h_km > float(aero["band_hi"])):
		center_band(aero, h_km)
	if not enabled or not aero["available"]:
		aero["enabled"] = false
		aero["outcome"] = "ok"
		aero["message"] = str(aero.get("off_reason", ""))   # B-043: no message of an earlier aerobraking calculation
		_use_propulsive_capture(plan)
		return
	aero["enabled"] = true
	var ctx: Dictionary = aero["ctx"]
	ctx["burn_budget_kms"] = maxf(0.0, _dv_available() - float(plan["dv_departure"]))
	ctx["energy"] = float(plan["arrival_energy"])   # (an orbit change: the energy follows the periapsis the first burn sets)
	var gm := float(ctx["gm"])
	var radius := float(ctx["radius"])
	var rp_t := float(plan["rp_t"])
	var ra_t := float(plan["ra_t"])
	var result := run_passes(ctx, h_km, n, FINAL_DT)
	var status := str(result["status"])
	aero["burn_assist"] = false
	var assist := float(result.get("burn_dv", 0.0))   # B-044: burns right after the passes that keep the ship in orbit
	aero["assist_dv"] = assist
	aero["assist_burns"] = result.get("burns", [])
	var budget_short := false
	var escape_burn := -1.0
	var escape_needed := 0.0
	var early_leave := false
	if status == "escape":
		# Still too fast after the passes: a burn after the last pass can finish the capture if the tanks hold enough
		# delta-v. Otherwise the ship flies past (it is not lost: it keeps its orbit around the Sun).
		var soi_km := float(ctx.get("soi_km", 1.0e11))
		var left_before_last := true   # (a ship that leaves the space of the body after an earlier pass never comes back for the next one)
		for earlier in (result["ras"] as Array).slice(0, maxi(n - 1, 0)):
			if float(earlier) >= soi_km:
				left_before_last = false
		if left_before_last:
			escape_needed = escape_capture_dv(gm, radius + h_km, float(result["energy"]), rp_t, ra_t) + axis_turn_dv(plan)
		else:
			early_leave = true
		if left_before_last and escape_needed + assist <= _dv_available() - float(plan["dv_departure"]):
			status = "ok"
			escape_burn = escape_needed
			aero["burn_assist"] = true
		else:
			status = "flyby"
	if status == "ok" and assist > 0.0 and escape_burn < 0.0:
		var finishing := final_dv(gm, radius + h_km, float(result["ra"]), rp_t, ra_t) + axis_turn_dv(plan)
		if assist + finishing > _dv_available() - float(plan["dv_departure"]) + 1.0e-6:
			status = "flyby"
			budget_short = true
	aero["heat"] = float(result["heat"])
	aero["peak_g"] = float(result["peak_g"])
	aero["peak_flux"] = float(result["peak_flux"])
	aero["pass_days"] = float(result["seconds"]) / float(maxi(n, 1)) / 86400.0   # the time of one pass (also for a fly-by: the glow and the turn use it)
	aero["outcome"] = status
	# The shield display never goes beyond what the shield had before the manoeuvre, or below zero.
	var capacity := maxf(float(ctx["shield_capacity_mj_m2"]), 0.000001)
	var left := float(ctx["shield_left_mj_m2"])
	aero["shield_before"] = left / capacity
	aero["shield_after"] = clampf(left - float(result["heat"]), 0.0, left) / capacity
	if status != "ok":
		if status == "flyby" and early_leave:
			aero["message"] = "An early pass throws the ship out of the space of %s, so it never comes back for the next pass: it will fly past and stay on its orbit around the Sun. Lower the periapsis or add passes." % plan["target_name"]
			plan["capture_legs"] = []
			plan["t_end"] = float(plan["t_arr"])
			plan["warning"] = ""
		elif status == "flyby" and budget_short:
			aero["message"] = "The burns after the passes (%.0f %s) and the final burns do not fit into the propellant that is left: the ship will fly past %s and stay on its orbit around the Sun. Lower the periapsis or add passes." % [
					UnitFormat.speed_ms(assist * 1000.0), UnitFormat.speed_ms_unit(), plan["target_name"]]
			plan["capture_legs"] = []
			plan["t_end"] = float(plan["t_arr"])
			plan["warning"] = ""
		elif status == "flyby":
			aero["message"] = "The ship is still too fast to be captured, and the propellant is not enough for a burn that captures it (%.0f %s needed after the passes): it will fly past %s and stay on its orbit around the Sun. Lower the periapsis or add passes." % [
					UnitFormat.speed_ms(escape_needed * 1000.0), UnitFormat.speed_ms_unit(), plan["target_name"]]
			plan["capture_legs"] = []   # the ship stays on the transfer orbit
			plan["t_end"] = float(plan["t_arr"])
			plan["warning"] = ""
		else:
			aero["message"] = "The ship slows down too much: it cannot get out of the atmosphere again, so there is no orbit."
			_use_propulsive_capture(plan)   # only for the legs; the ship is lost on arrival
		aero["days"] = 0.0
		aero["final_dv"] = 0.0
		plan["outcome"] = status
		plan["outcome_text"] = str(aero["message"])
		plan["dv_arrival"] = 0.0
		aero["entry_times"] = [float(plan["t_arr"]) - 300.0 / 86400.0]
		return
	aero["message"] = ""
	aero["pass_days"] = float(result["seconds"]) / float(maxi(n, 1)) / 86400.0   # the time of one pass: the orbit changes during it
	var ras: Array = result["ras"]
	var ra := float(result["ra"])
	var rp := radius + h_km
	var final_burn := escape_burn if escape_burn >= 0.0 else final_dv(gm, rp, ra, rp_t, ra_t) + axis_turn_dv(plan)
	aero["final_dv"] = final_burn
	aero["ra"] = ra
	# Orbit legs: one ellipse after each pass (a full period each, the last only to its apoapsis), possibly an
	# ellipse for raising the periapsis, and finally the target orbit.
	var phase := _arrival_axis(plan)
	var t := float(plan["t_arr"])
	var legs: Array = []
	var entry_times: Array = []   # when the ship reaches the upper atmosphere before each pass
	var lead_days := (float(result["seconds"]) / float(n) * 0.5 + 60.0) / 86400.0
	var apoapsis_too_low := burns_at_once(ra, rp_t, ra_t)
	for i in n:
		entry_times.append(t - lead_days)
		var last := i == n - 1
		var ra_i := float(ras[i])
		if last and apoapsis_too_low:
			ra_i = ra_t   # the apoapsis is set to the target apoapsis with a burn at once
		var period := _period_days(gm, 0.5 * (rp + ra_i))
		legs.append({"parent": plan["target_id"], "segment": _ellipse(gm, rp, ra_i, t, phase, 0.0, orbit_dir(plan)), "t_start": t,
				"label": "Aerobraking pass %d of %d" % [i + 1, n] if not last else "After aerobraking pass %d of %d" % [n, n],
				"kind": "aero"})
		t += period * (0.5 if last else 1.0)
	var final_anomaly := 180.0   # the ship is at the apoapsis of the target orbit
	if not apoapsis_too_low and absf(ra - ra_t) > 0.005 * ra_t:
		legs.append({"parent": plan["target_id"], "segment": _ellipse(gm, rp_t, ra, t, phase, 180.0, orbit_dir(plan)), "t_start": t,
				"label": "Raising the periapsis", "kind": "aero"})
		t += _period_days(gm, 0.5 * (rp_t + ra)) * 0.5
		final_anomaly = 0.0
	if axis_turn_deg(plan) > 0.5:
		# The ship is on the target-shaped orbit at the aimed axis; the axis is turned at the next crossing point.
		legs.append({"parent": plan["target_id"], "segment": _ellipse(gm, rp_t, ra_t, t, phase, final_anomaly, orbit_dir(plan)),
				"t_start": t, "label": "Capture orbit around %s" % plan["target_name"], "kind": "aero"})
		t = _append_turn_leg(legs, plan, t, final_anomaly)
	else:
		legs.append({"parent": plan["target_id"], "segment": _ellipse(gm, rp_t, ra_t, t, _axis_deg(plan), final_anomaly, orbit_dir(plan)),
				"t_start": t, "label": "Orbit around %s" % plan["target_name"], "kind": "orbit"})
	plan["capture_legs"] = legs
	aero["entry_times"] = entry_times
	plan["dv_arrival"] = final_burn + assist
	plan["t_end"] = t
	aero["days"] = t - float(plan["t_arr"])
	_set_target_outcome(plan)


## The propellant the plan may use at the target (km/s): what is left, less what a later stage needs (reserve_kms).
static func _dv_available() -> float:
	return GameState.dv_left_kms() - reserve_kms
