# Prototype body data: notes

Files:

- `data/bodies.json` – Sun, Earth, Moon, Mars, Phobos, Deimos and Ceres, following the data model in the design document.
- `data/facilities.json` – the Ceres propellant plant (exists from the start in this prototype).
- `scripts/kepler.gd` – Kepler orbit maths (position of a body on rails at any date).
- `scripts/system_view.gd` – a small test view that draws one system at a time and has time warp (build order step 4).

## Using them in the Godot project

1. Copy the three files into the project, keeping the folders (`res://data/`, `res://scripts/`).
2. Create a new scene with a **Node2D** as root, attach `system_view.gd`, save it as `main.tscn` and set it as the main scene. Bodies are plain circles, so no graphics are needed.
3. Run it. Tab (or a tap on the top half of the screen) switches between the Sun, Earth and Mars systems, Space pauses, and `+` / `-` (or a tap on the bottom right / left) change the time warp.
4. **Android export:** Godot only packs `.json` files if told to. In Project, Export, Resources, add `*.json` to "Filters to export non-resource files/folders". Without it the phone build shows an empty screen and logs "Cannot read res://data/bodies.json".

These scripts were not run in Godot (it is not available where they were written). The orbit maths was mirrored line by line in Python and checked (see below), but expect to fix a typo or two the first time you press Play. Send me the error text if so.

## Units and conventions

Kilometres, days (Julian Date), degrees, GM in km³/s², mass in kg. The game starts on 2035-01-01 00:00 (JD 2464328.5). Dates are treated as a plain continuous day count, with no leap-second or time-scale corrections.

## Sources

| Data | Source |
| --- | --- |
| Earth and Mars orbits | [JPL, Approximate Positions of the Planets](https://ssd.jpl.nasa.gov/planets/approx_pos.html), Table 1 (valid 1800–2050), base values at J2000 |
| Moon, Phobos, Deimos orbits | [JPL, Planetary Satellite Mean Elements](https://ssd.jpl.nasa.gov/sats/elem/sep.html), epoch 2000-01-01.5 |
| Ceres orbit | [Space Reference](https://spacereference.org/asteroid/1-ceres-a801-aa), which lists the JPL Small-Body Database elements for epoch JD 2460200.5 (rounded values) |
| GM of Sun, Earth, Moon, Mars | [JPL, Astrodynamic Parameters](https://ssd.jpl.nasa.gov/astro_par.html) (DE440); astronomical unit 149 597 870.7 km |
| Radius and GM of Moon, Phobos, Deimos | [JPL, Planetary Satellite Physical Parameters](https://ssd.jpl.nasa.gov/sats/phys_par) |
| Mass, radius, atmosphere of Earth, Mars; Sun mass and radius | NASA fact sheets: [Earth](https://nssdc.gsfc.nasa.gov/planetary/factsheet/earthfact.html), [Mars](https://nssdc.gsfc.nasa.gov/planetary/factsheet/marsfact.html), [Sun](https://nssdc.gsfc.nasa.gov/planetary/factsheet/sunfact.html) |
| Moon mass | NASA Moon fact sheet (archived copy) |
| Ceres mass and radius | [Wikipedia, Ceres](https://en.wikipedia.org/wiki/Ceres_(dwarf_planet)) infobox (mass from Dawn) |

## Derived values (computed, not copied)

- **Earth and Mars elements:** semi-major axis = a (AU) × AU; argument of periapsis = long.peri. − long.node; mean anomaly = L − long.peri.; mean motion = rate of L ÷ 36525 (gives 365.256 d and 686.980 d, matching the NASA fact sheets).
- **Phobos and Deimos mean motion:** Kepler's third law from a and GM (Mars + moon). Periods come out at 0.31898 d and 1.26243 d.
- **Ceres mean motion and GM:** mean motion from Kepler's third law (period 1681 d); GM = mass × G (62.63 km³/s²).
- **Phobos and Deimos mass:** GM ÷ G.
- **Moon mean motion:** from JPL's period of 27.322 d. Kepler's law with the mean semi-major axis would give 27.285 d (the Sun perturbs the Moon's orbit), which would drift the phase noticeably over decades.

## Simplifications to keep in mind

- **2D map:** inclination is ignored. Each orbit is an ellipse in the map plane, rotated by the longitude of periapsis (node + argument of periapsis).
- **Apsides held fixed:** only the mean anomaly advances over time. Against JPL's own formula with precession rates, the Earth ends up about 10 000 km off in 2035 and Mars about 77 000 km (about 0.0005 AU), which is invisible on a map and irrelevant to transfer planning.
- **Earth** is placed on the Earth-Moon barycentre orbit from Table 1. The offset between the barycentre and Earth's centre is ignored.
- **Mars GM** is the Mars system value, including Phobos and Deimos.
- **Phobos and Deimos** use mean elements referred to Mars's local Laplace plane. JPL says these are not meant for ephemeris use, and in a 2D map their orientation angles only set the starting phase.
- **Ceres elements** come from a secondary mirror and are rounded (a to 0.001 AU, angles to 0.01°). The error is small for a game, but the exact SBDB values should replace them when convenient.
- **Orbit segments:** each body has a list. A later segment (for example after an impact) is added with its epoch set to the time of the change, and `Kepler.segment_at` picks the one that applies.

## Proposals for you to review (not from sources)

- **Resources:** each entry has `quantity_kg` (-1 = infinite) and `availability` (0 to 1, high = easy to extract). Availability sets the output per unit of time for given labour and equipment; cost differences only follow from needing more labour, equipment, life support or robots. Water (one id, `water`, for liquid and ice alike) is infinite on Earth (availability 1.0, already liquid), the Moon (0.15), Mars (0.3) and Ceres (0.4). The availability numbers are placeholders for balancing. Sun, Phobos and Deimos have none.
- **Home flag:** Earth.
- **Impact thresholds:** left as `null` until the impact system is built.
- **Atmosphere:** only surface density and scale height are set (exponential model). The altitude where an atmosphere starts to matter is left to a game constant, so it can be tuned.
- **Draw colours:** only used by the test view.

## Checks performed

- On 2035-01-01 Earth is at heliocentric longitude 99.9° and 0.9833 AU, as expected shortly before the early-January perihelion.
- On 2035-09-15 Earth and Mars are at the same heliocentric longitude (351.5° and 351.8°), which fits the Mars opposition of mid-September 2035 (the date is from memory, not from a source). This checks both orbits and their mean motions together.
- The mean motions from the table and from Kepler's third law agree to 4 × 10⁻⁶ (Earth) and 2 × 10⁻⁵ (Mars).
- After exactly one period every orbit returns to its starting position to within 0.0002 km, so the Kepler solver converges.

## Facilities and routes (build step 8)

- **Ceres propellant plant** (`facilities.json`): turns water into propellant. Output per day = peak output (1000 kg/day) x availability of water on Ceres (0.4) x conversion (1.0), so 400 kg/day. Storage 500 000 kg, starts empty at the game start. All numbers are placeholders.
- **Arrival orbit altitude** (`default_orbit_altitude_km` in `bodies.json`): Earth 400, Moon 100, Mars 400, Ceres 100, Phobos 20, Deimos 20. Placeholders.
- **Destinations** from a body: its own moons; if it is a moon, its planet and the planet's other moons; and the other planets and dwarf planets that orbit the Sun.
- **Route types** (all 2D patched conics): a moon of the body the ship orbits; from a moon to its planet (no window, leaves at once); between two bodies around the same body (two planets, or two moons of one planet); from a moon to another planet (the escape from the moon is estimated assuming the best direction, the moon's phase is not modelled). The transfer is a half ellipse between the actual distances at departure and arrival.
- **Fuel:** the ship's tank is a delta-v tank. The design screen saves the total propellant and delta-v, and the game derives an equivalent single stage from them with the rocket equation (average exhaust velocity weighted by propellant mass, and the dry mass that gives the same delta-v). So the propellant mass and the delta-v of the tank always match, and burns and refuelling move along that curve. Stage structure is ignored.

## Settings and facility types (step 8c)
- `settings.json`: start budget (EUR, placeholder 1e12) and the facilities present at game start (a shipyard at Earth).
- `facilities.json`: facility *types*. A type with a `kit` can be bought at a shipyard (cost_eur, mass_kg of the ship's payload) and deployed from orbit at a body where its resource is available. The Ceres propellant plant is no longer prebuilt.

## Aerobraking (step 9)
- `atmosphere` in bodies.json (Earth, Mars): surface_density_kg_m3, scale_height_km, min_periapsis_altitude_km (placeholder floor for the planner). Exponential atmosphere; a pass starts where the density is 1e-8 kg/m3.
- Pass physics: RK4 in the orbit plane, drag = rho v^2 / (2 beta), beta = mass / (1.5 x area); heating = Sutton-Graves (1.7415e-4 sqrt(rho / nose radius) v^3), nose radius = sqrt(area / pi); peak deceleration in g. No lift.
- Ship size: sphere of 300 kg/m3 average density (placeholder until hull types exist). Shield: 3 kg per m2 per cm of thickness, 15 MJ/m2 of heat load per cm (placeholders). Planner uses at most 80% of the remaining shield and a 10 g limit (cargo only).
- Several passes use the same periapsis altitude; the trim burns between passes are ignored.
- A pass that overloads the shield or the g limit damages ship health in proportion to the excess. `shield_cost_eur_per_kg` (settings.json) is the price of a replacement shield at a shipyard.

## Target orbit and warnings (step 9b)
- Every transfer ends in a target orbit {rp_alt_km, ra_alt_km, offset_deg} (altitudes above the surface), chosen with the `OrbitControl` (periapsis, apoapsis, axis offset) and remembered per destination body in `GameState.target_orbits`. Default: circular at the body's `default_orbit_altitude_km`. The control keeps apoapsis > periapsis by an invisible 0.001 km (lowering the apoapsis below the periapsis pulls the periapsis down; raising the periapsis above the apoapsis pushes the apoapsis up). A gap below 0.0105 km counts as circular; then the offset is greyed out.
- Capture burn = burn at the target periapsis from the arrival energy (`TransferPlanner.capture_dv`). The axis offset only turns the drawn orbit (it counts from the arrival direction, costs no delta-v, and makes the ship jump to the rotated orbit at the end); a ship leaves a non-circular orbit from its periapsis.
- Aerobraking passes aim at the target apoapsis, then burns raise the periapsis to the target and fix the apoapsis (`AeroBraking.final_dv`). The periapsis slider covers +/- 8 km around the current setting (`BAND_KM`); the number box takes any altitude.
- The shield display is the shield's capacity before the manoeuvre, saturated between that and 0%.
- Nothing is blocked: the planner only warns (plan["outcome"], plan["warning"]). Outcomes: `too_slow` (the ship slows down too much to leave the atmosphere), `escape` (still too fast), `crash` (target periapsis below the surface), `burn_up` (below `min_periapsis_altitude_km`). On arrival such a ship is lost (health 0; placeholder rules). A target periapsis inside the upper atmosphere only warns that the orbit will decay.
- Axis offset (revised): when a ship arrives from outside the sphere of influence, the arrival periapsis is assumed to be aimed at the target orbit's axis, so passes and the final apoapsis already sit where the target orbit wants them (no cost, no jump). The Moon-to-Earth transfer cannot be aimed; there the axis is turned with a burn at the crossing of the two ellipses (`AeroBraking.axis_turn_dv`, 2 e sqrt(mu/p) sin(offset/2)), added to the arrival burn.
- Departure from a non-circular parked orbit (planets/moons leaving the origin's sphere of influence): the periapsis direction needed for the escape is `TransferPlanner.escape_axis_deg`; within `AXIS_TOLERANCE_DEG` (10) the ship leaves from the periapsis at no extra cost, otherwise the plan adds a circularisation burn at the apoapsis and leaves from the apoapsis radius (included in dv_departure, shown in the plan text; plan["dv_circularize"]). Transfers to a moon of the origin body use the ship's real orbit position already; departures from a moon to another planet are unchanged (direction not modelled).
- If periapsis and apoapsis of the parked orbit differ by less than 5% of the apoapsis (`MissionPlanner.NEARLY_CIRCULAR`), the orbit's axis is ignored for departures: no circularisation, the ship leaves from the periapsis radius.
- Launch safeguards: a plan that ends badly asks for confirmation ("Launch anyway"). "Abort launch" is available between Launch and the departure burn: refunds the launch cost, uncommits the plan and keeps all its settings. A plan can still be launched up to 5 minutes after its departure time (`LATE_LAUNCH_DAYS` in orbit_view.gd).

## Course changes in flight (step 9g)
- The mission can be changed at any time during a transfer: Plan is available in flight (not during aerobraking passes). `CourseChange` solves Lambert's problem from the ship's position (on its current leg) to the chosen destination for 160 + 60 flight times and takes the cheapest burn + capture. Destinations are the bodies that orbit the body the ship is flying around. Hyperbolic/retrograde solutions and ones that dip below 1.05 x the central body's radius are skipped.
- The plan being followed is kept (`GameState.saved_plan`) while a draft is open ("Keep current course" drops the draft); time keeps running on the saved plan. Launching the change replaces the later legs; "Abort launch" before the burn restores the old plan. A course change costs no launch cost, only propellant: nothing stops the player from planning something the fuel cannot finish, and a ship left on a bad course is lost.
- Warnings about an unsafe plan are shown in an orange line above the plan text before launching; the button stays "Launch", and the confirmation dialog appears when pressing it.
- Fix (9i): course-change plans now get their capture legs/aerobraking data (`AeroBraking.setup_plan`); before, the ship never switched to the orbit around the destination.
- The destination list always includes the body the ship is at (parked) or flying around (in flight), shown as "Orbit around X". Parked: `MissionPlanner._plan_orbit_change` (two apsis burns, defaults to the current orbit). In flight around a planet/moon: `CourseChange._central_plan` finds the cheapest burn onto a path with the chosen periapsis (any periapsis direction), then the usual capture/aerobraking applies. Not offered in the Sun's frame.
- Top bar (9m): shows the ship name next to the date, and a line about the current orbit (`GameState.orbit_status_text`): periapsis/apoapsis altitude, axis angle (or "circular"), current altitude, speed relative to the body ("Airspeed" while below the atmosphere's upper limit; on-rails legs do not model the speed lost in a pass).
- Landscape/phone (9p): the top bar's content sits in a ScrollContainer whose height is limited to 70% (portrait) or 55% (landscape) of the screen; the rest scrolls (drag or scroll bar). Set the orientation in Project Settings > Display > Window > Handheld.

## Orbit decay and the launch popup (9q)
- A parked orbit whose periapsis is inside the atmosphere now decays. On first use `GameState._ensure_decay(leg)` simulates
  the passes with `AeroBraking.simulate_pass` (periapsis fixed, energy lost per pass; once there are many passes, one
  simulated pass stands for a group of them, at most 60 groups). Each group sets the leg's orbit lower at its last pass.
- Time warp drops to 1 min/s at the start of every pass (`_next_decay_entry`). Heat goes to the shield and g-load damages
  the ship via `_take_aerobraking_effects`. When the apoapsis falls to the top of the atmosphere (or a pass crashes) the
  ship is lost (placeholder: health 0 + message). Changing the orbit before that replaces the leg, so the decay stops.
- The launch warning popup wraps its text and is sized from the window width (autowrap, `wrap_controls`).

## Ship lost animation (9r)
- `art/burnup/lander_000..119.png`: 10 s, 12 fps, 480x300, transparent. Rendered from the "Burning up / Lander burning up"
  SVG of the "Ship sprite samples" canvas (Heating board) with Playwright (SMIL time stepped per frame). The lifting-body
  version can be rendered the same way when that hull exists.
- `GameState.lost_event` {text, burn} is set by `_lose_ship` (doomed arrival, or decay) and pauses time. `burn` is true when
  the loss happened at a body with an atmosphere. The orbit view shows `ShipLostOverlay` (new class_name: run
  `godot --headless --import` once): animation, tap to skip, then an AcceptDialog "Ship lost". Crashes on bodies without an
  atmosphere (Moon) show only the popup.

## Cargo mass in the delta-v (9s)
- `GameState.dry_mass_kg()` = empty ship + cargo kits. `fuel_for_dv`, `dv_for_fuel`, the aerobraking ballistic coefficient and
  `ship_mass_after_departure` use it, so loading a kit lowers the delta-v for the same propellant and deploying it raises it again.
  Propellant mass is unchanged by loading/deploying. (The shield mass is still part of the empty ship.)

## Delta-v with and without payload (9t)
- Ship design screen shows "Delta-v without payload" (only the shield on top of the stages) and "Delta-v with full payload".
  The saved design adds `dry_empty_kg` and `empty_dv_ms`. Before this the saved `dry_eff_kg` included the full payload mass,
  which made 9s count the payload twice. `GameState.ship_dry_kg` is now the EMPTY ship (older saves: dry_eff minus payload);
  `dry_mass_kg()` adds the kits actually carried. The tank capacity in the orbit screen is the delta-v of a full tank with the
  current cargo. Re-open the ship design screen once so it re-saves the design.

## Launch window search from a high orbit (9u)
- Ship in orbit around a planet, target one of its moons: the window search now covers at least 1.2 synodic periods of ship
  and moon (up to 40 ship orbits) instead of 1.5 ship orbits. Example: ship at 4000 km around Mars to Phobos (synodic
  period about 3 ship orbits) found no window when the ship was on the wrong side.

## Step 10a: automatic view switching
- The "auto" view (default) now follows the ship's distance, not only the leg it is on. Each body has a view radius =
  the distance its view shows at the edge of a portrait screen (the widest orbit of its children, or 4 body radii, or 1.5x the
  ship's orbit when it has no children; divided by VIEW_FILL 0.9). The view shows the body with the smallest view radius that
  contains the ship (Moon -> Earth -> Sun). It switches in at the radius and out at 1.15x the radius (VIEW_HYSTERESIS).
- So arriving at Mars, Ceres or Earth shows the local view as soon as the ship is that close, not at the insertion burn.
- Not done yet: the same rule for manual panning/zooming, and the transfer route is only drawn in the view of the frame it was
  planned in (so right after leaving Earth the route appears once the view has switched out to the Sun).

## Step 10b: local route, warp slowdown, orbit morph
- Local route: the model jumps from the orbit around the origin to the transfer orbit (and from it to the orbit around
  the target) at one point. `GameState.transfer_leg_for_plan` stores that jump (`from_offset`/`to_offset`, with
  `from_ref`/`to_ref`) in the transfer leg; `leg_rel_with_offsets` fades it out over 6x its size, so the ship leaves
  the parking orbit and arrives at the first orbit without a jump. The map draws the same path (`_draw_local_route`) in the
  view of the origin body (escape) and of the target body (insertion), plus the orbits the plan creates there
  (aerobraking passes faint, final orbit stronger). Course changes in flight have no escape part.
- Warp: when the ship is about to get inside the view of a smaller body (smallest_view), time is stopped at the moment it
  gets in and the warp drops to AERO_WARP_INDEX (1 min/s). Leaving a view does not change the warp.
- Morph: legs have `morph_days` = burn time of the burn (`GameState.burn_days`, from the ship's thrust: new
  `thrust_kn` in the saved design = thrust of stage 1, default 1000 kN until the design screen has been opened) or the
  time of one aerobraking pass (`aero["pass_days"]`). Around the start of such a leg (centred on it) the shown orbit goes
  linearly from the old periapsis/apoapsis/axis to the new ones (`GameState.morph_at`); the top bar numbers follow. At
  an insertion the orbit shrinks from a wide ellipse with the same periapsis. No morph for departure to another body.
- Aerobraking warnings: the planner keeps 20% of the remaining shield in reserve (HEAT_MARGIN 0.8). Below that margin it
  suggests propulsive capture (message now says so); if the player switches aerobraking on anyway, the plan shows a
  "Warning: heat shield will have only X% left" line.

## Step 10c: tangential escape/insertion, morph slowdown
- Near the origin / target body the displayed path is now a hyperbola (`GameState._hyperbola`, Kepler's equation for H) with
  its periapsis at the point where the ship leaves the parking orbit / enters the first orbit, so it joins that orbit
  tangentially, and the speed at infinity of the transfer (arrival: sqrt(2 * arrival_energy); departure: the speed of the
  transfer relative to the body). Far away the transfer's own path is used, turned about the body by `delta` so that it comes
  in / goes out along the hyperbola's asymptote; the two are blended between 3 and 12 periapsis radii (`_blend_hyperbola`). It is only
  used when the transfer starts / ends at the body itself; otherwise (for example a moon leaving for another planet) the older
  faded offset is used. The ship follows the same path, with the periapsis at the burn time.
- `_leg_rel` subtracts the body's position inside the leg's own system when the view body is a moon of the leg's parent
  (full precision for Phobos/Deimos views).
- Warp drops to 1 min/s at the start of every visible morph (burns and aerobraking passes that change the orbit), so the morph
  can be watched at high warp. Departure for another body has no morph and no slowdown.

## Orbit change from a circular orbit (10d)
- The burn happens where the ship is, so the transfer ellipse's axis is now taken from the ship's position at the burn (it was the
  circular orbit's arbitrary axis, which showed the ship on an offset ellipse until the second burn). The final circular
  orbit uses the same axis, so the ship continues from where it is. Non-circular orbits are unchanged (burns at the apsides).

## Orbit change ends with its last burn (10e)
- When only one apsis changes (second burn below 0.1 m/s), the orbit change is a single burn: the plan ends one second after it
  (the ship is at the burn point on the new orbit) instead of waiting half an orbit for a zero burn at the other apsis.

## Orbit change from a circular orbit to an orbit with an axis (10f)
- The axis offset counts from the circular orbit's axis (0 deg, as the top bar shows axes). The burns now happen where the new
  periapsis / apoapsis will be, so the ship first flies to that point (no "orbiting through the body"). No extra axis-turn burn.
- If the first burn would be zero (only the second apsis changes), it is skipped: the mission is one burn, at whichever apsis
  point of the new orbit the ship reaches first, and the plan ends with it.

## Step 10h – revert of 10g
The offset is the angle of the PERIAPSIS axis again (0 deg = right, counter-clockwise), for orbit changes and transfers alike, as in 10f.
The top bar shows "axis" again (periapsis direction). 10g and the first 10h attempt were withdrawn.

## Step 10i – approach/escape path lies on the real hyperbola line
- The far part of an insertion / escape path (the transfer's own path) used to aim at the body's centre, so near the body it
  had to bend sharply into the hyperbola ("hook"). The far path is now also moved sideways by the impact parameter
  (`hyp["shift"]`, `_asymptote_shift`), so it lies on the asymptote of the hyperbola that touches the orbit tangentially.
- The blend zone now reaches from 3 rp out to max(12 rp, 6 a), so the hyperbola takes over smoothly.

## Step 10j – view entry found at any warp
- The view-switch logic is generic (every body: view radius = widest child orbit / 0.9), but `_next_view_entry` only compared the
  views at the start and end of a time step. At a high warp the ship can fly through a small view (Mars: ~26,000 km) and out
  again within one step, so the slowdown never triggered and the view only changed when the aerobraking pass stopped the warp.
  Earth/Moon have big views, so the ship was still inside at the end of the step. The interval is now sampled (every 0.01 day, at
  most 160 samples) and the entry time is found by bisection.

## Step 10k – earliest stop event wins
- Real cause of the missed view change: `advance()` handled the stop events one after the other (aerobraking entry, morph start,
  view entry) and only looked at the next one if the previous had not already slowed the warp. At a high warp the pass/morph start
  came first, time jumped straight to it and the (earlier) view entry was never considered. Now all three are computed for the
  step and the earliest is used, so the ship stops where it enters the smaller view (the view then switches there).

## Step 10l – ship-lost texts in the past tense
- The text after a loss on arrival is built by `GameState._lost_text(outcome, target)` (crash, burn_up, too_slow, too fast) in the
  past tense; the planner's `outcome_text` (future tense) is still used for the warnings before launch. The decay message
  was already in the past tense.

## Step 10m – burn-up / crash handling
- Why the ship is lost below 25 km at Mars: `min_periapsis_altitude_km` in bodies.json (Mars 25, Earth 60) is a placeholder rule: a target
  orbit with its periapsis below it means "burn up", no matter the heat or the g-force (the heat shield display is only about the passes).
- When the target periapsis is lower than that limit the heat shield prediction is locked to 0% (`_set_target_outcome`).
- A predicted shield capacity below 20% (1 - HEAT_MARGIN) after the manoeuvre is shown in the colour of the warnings (the info label is a
  RichTextLabel now; a line starting with `WARNING_MARK` is coloured).
- The ship is lost when it blows up, not when the manoeuvre would have finished: `GameState._loss_time()` = the first arrival at the
  periapsis of the target orbit (the arrival itself for a propulsive capture). Time stops exactly there; `GameState.ship_lost` makes the
  screen draw no ship and no course, and the burn-up animation plays (not for a crash).
- A target periapsis altitude of 0 or less is a crash (also where there is no atmosphere). Text only for now: "The ship crashed into the
  surface of X and was lost." (animation later).

## Step 10n – top bar near another body
- While the ship is still on a transfer leg (Sun-centred) but inside the local view of a body, the top bar now shows
  "Approaching/Leaving X: altitude ... km | Speed ... km/s (relative to X)" instead of the periapsis, apoapsis and altitude of the
  transfer orbit around the Sun. The first aerobraking leg then takes over as before.

## Step 10o – zoom between views, double tap to focus
- Every change of the view (auto switching, the View button, a double tap) is now a zoom of `ZOOM_SECONDS` (0.7 s, real time) instead of a cut.
  `shown_frame` is the view that is drawn; `_update_zoom` starts a zoom (`zoom_from` -> `zoom_to`) when the chosen view (`_frame_id()`)
  differs. During the zoom both scenes are drawn (`_draw_scene`), the scale changes in equal ratios, the camera moves from one body to the
  other (linear in 1/scale, so it behaves like a real zoom into the point) and the scene that is left fades out, the one it goes to fades in
  (`scene_alpha`, `_fade`). If the chosen view changes during a zoom, that zoom is finished at once and the next one starts.
- Double tap (two taps within 400 ms) on a body of the shown view: the view focuses on it (View shows its name). A double tap on the body the
  view is centred on zooms out to the body it orbits (to "auto" for the Sun). A tap on a body does not change the warp any more; taps elsewhere
  in the bottom third still do.
- Not done yet: pinch zoom and panning by hand, and the automatic widening of the view when doing that.

## Step 10p – pinch zoom (camera instead of fixed frames)
- The view is now a camera: `cam_body` + `cam_offset` (km, the point at the screen centre relative to that body) + `cam_scale` (px/km).
  Zooming to a view (double tap, auto switching, View button) animates the camera (`_update_camera`, `_start_zoom`): scale in equal ratios,
  position linear in 1/scale; this replaces the two-scene cross-fade of 10o.
- Pinch with two fingers (or the mouse wheel on the PC) zooms about the point under the fingers and moves the view with them
  (`_zoom_about`); the view is then "free" (top bar: "View: free") and stays where it is. Pressing View once brings it back to the chosen
  view; a double tap on a body zooms to it; a change of the automatic view zooms there as before. Limits: MAX_PX_PER_KM (2 px/km) and
  MIN_SUN_FIT (a quarter of the scale that fits the Sun's system).
- `_draw` draws the scene of the camera's body, of its parent and of its children together (`_draw_scene`); a scene fades in when its view
  radius is more than ~16-60 px on the screen, its orbit lines fade out when it is much bigger than the screen (markers stay).
  `_rebase` moves the camera's reference body to the one whose own view has about the current scale (nothing changes on the screen).
- `GameState.body_rel_to(from, to, jd)` gives the position of one body relative to another with small numbers.
- A tap now counts when the finger is lifted, and not right after a pinch.

## Step 10q – no View button, always the automatic view
- The View button is gone (TopBar.setup with "" leaves it out); the chosen view is always the automatic one (`_frame_id()`), the camera
  follows it and zooms when it changes. Pinch / wheel / double tap move the camera by hand ("free") until the automatic view changes or until
  two quick taps on empty space bring the camera back to the automatic view.
- Double tap on a body: zoom to it (the camera then stays on it). Double tap on the body the camera is already on: zoom out to the body it
  orbits (for the Sun: back to the automatic view).

## Step 10r – drag to move, snap out to the parent's view, planner resets the view
- One finger (or the left mouse button) drags the view (`_pan`, from InputEventMouseMotion, which Godot also makes from a single touch; it is
  ignored while two fingers are down). After DRAG_START_PX the gesture is a drag, the release is not a tap.
- Zooming out by hand below SNAP_OUT (0.8) of the normal view of the body the camera is on zooms (animated) to the normal view of the body it
  orbits: Moon -> Earth -> Sun. Pinch input is ignored while a zoom to a view is running.
- Pressing Plan (a draft was made) zooms back to the automatic view.

## Step 10s – ship orbit always visible and green, smaller rings
- The ship's orbit (and the morphing orbit) is drawn in `_draw_ship_orbit`, not inside the scene of its body, so it no longer fades away when
  the scene is much bigger than the screen (zoomed in at Earth). It is hidden only when it is less than ~2 px above the body (fades in
  2-6 px) or more than 8 half-screens wide. Colour green; planned courses stay blue.
- The ring around small bodies is drawn when the body's true radius is below RING_BELOW_PX (2 px), so Earth has none in its default view
  (about 4 px), while the Moon in the Earth view and the moons of Mars still have one.

## Step 10t – snap-out threshold
- SNAP_OUT is 1/1.5: the view zooms out to the parent's view once it is 50% wider than the body's own default view (was 20%).

## Step 10u – drag delay after zooming
- One-finger dragging is blocked for PAN_DELAY_MS (0.5 s) after the last pinch / wheel movement; while blocked the drag start point follows the
  finger, so that the view does not jump when one finger leaves the screen a little before the other.

## Step 10v - body sprites (untested)
- New `scripts/sprite_library.gd` (`class_name SpriteLibrary`): finds the pack in `res://sprites/` or `res://asteroid-miner-sprites/sprites/`, loads textures, normal maps, pivots from `sprites.json` (image centre if the json is unreadable) and the shader `sprite_lit.gdshader`. **Run `godot --headless --import` once** (new class_name).
- `orbit_view.gd`: bodies are drawn as Sprite2D nodes in a layer behind the control's own drawing, scale = radius_px / 192. They fade in over the coloured disc between 2.5 and 7 px radius; the small-body ring is unchanged. No rotation (tilted planets stay fixed in space). Light direction = Sun direction on screen (planets/moons elevation 0). Sun unlit. Earth snow overlay opacity = 0.5 - 0.5 * dot(to_sun, up). Rings drawn if a `<id>_rings` sprite exists.
- Ship sprites (glow, flame) and the landing/burn-up animations are not yet integrated.

## Step 10w - sprite jitter fix
A body drawn by two scenes (e.g. Ceres by the Sun's scene and its own) used the far, 32-bit-imprecise position. Sprite requests now carry the scene rank; the camera body's own scene wins, opacity is the larger of the two.

## Step 10x - body drawn once
Bodies that two scenes both draw (e.g. Ceres in the Sun's scene and its own) now get their disc, name and sprite from one scene only (the camera's own scene if visible), with the larger opacity.

## Step 10y - capture burn at the last aerobraking pass
Before, when the passes left the apoapsis above the target apoapsis, the ship coasted out to that far apoapsis, raised the periapsis there (cheap) and came back to lower the apoapsis at the new periapsis. Not a g-limit: just the cheapest sequence in delta-v, but it takes weeks. Now `AeroBraking.burns_at_once`: if the apoapsis after the last pass is below the target periapsis or more than 0.5% above the target apoapsis, the apoapsis is set to the target apoapsis with a burn right after the last pass; the periapsis is raised half an orbit later. A few % more delta-v at most. Several passes (planner or player) work as before; the burn follows the last one.

## Step 10z - ship sprite (untested)
- The ship is drawn with `ships/modular` (constant `SHIP_SPRITE` in orbit_view.gd, until ship design picks the hull), 36 px long at every zoom, pointing along its velocity on the screen, lit by the Sun (elevation 0.56), with the `_glow` layer added on top (additive blend).
- Engine flame (`effects/flame_vacuum`) while a burn is going on: `GameState.burning_at(jd)` (morph window of a non-pass leg; capture legs now carry `is_pass`). The flame is placed at the left edge of the hull (+12 px); adjust `ship_flame.position` if it sits wrong.
- The triangle is still drawn if the sprite pack is missing. Aerobraking plasma and the other effects are not integrated yet.

## Step 10aa - ship view changes
- One-finger drag delay after a zoom: 0.25 s (`PAN_DELAY_MS`).
- The ship is the white triangle until the sprite (36 px) would cover at most 25% of the diameter of the body it orbits (body radius >= 72 px); between 48 and 72 px the two cross-fade.
- Ship lock: when the camera is on the body the ship orbits and that body's centre is farther than half the smaller screen dimension from the screen centre, `cam_offset` follows the ship. Dragging releases the lock until the body centre is in view again; zooming out by hand and the automatic view change work as before.
- Shadow: the ship is lit at 25% (`SHIP_SHADOW_LIGHT`) inside the cylinder shadow of the body it orbits (soft edge, 2% of the radius); the glow layer stays bright. Done through `sun_strength` and `ambient` of the shader.

## Step 10ab - ship focus, tap pool, lock fix
- Ship lock now needs the view to be zoomed beyond the normal view of the body the ship orbits (`_ship_locked`), works whatever body the camera is counted from, and dragging is ignored while locked (zoom out to leave). The old "released by dragging" flag (which could stay stuck after a stray drag at the end of a pinch) is gone.
- Double tap on the ship (target `"@ship"`, tappable when the view shows the ship's body in its own size) zooms to the ship (0.7 s, same animation as bodies); the ship then stays locked in the centre. Double tap again: zoom out to the body it orbits. `_ship_focus_scale()` puts the orbit at 1.5 x half the smaller screen dimension.
- Taps hit only: the camera body, its parent, and either its moons and the ship (view at least 0.7 x the body's own view) or the parent's other children (zoomed out). A tap on a planet in the solar view no longer hits the moon on top of it.

## Step 10ac - lock only near the ship, softer shadow
- `_ship_locked` also requires the ship to be within 0.6 x the larger screen dimension of the screen centre. Zooming to the Moon (ship orbits Earth) or to Mars no longer snaps to the ship.
- Shadow edge width grows with the ship's altitude: 2% of the body radius near the surface up to 62% at three radii.

## Step 10ad - time controls under big bodies
A body whose on-screen radius is over 60 px no longer takes taps in the bottom third of the screen (the tap changes the warp); before, a zoomed-in planet covering the bottom swallowed them.

## Step 10ae - aerobraking heating effect (untested)
- `GameState.heat_at(jd)` (0..1): during an aerobraking pass (morph window of a pass leg) a bell curve (sin^2) times the pass's strength, which is the plan's peak heat flux mapped logarithmically between `heat_effect_min_mw_m2` (0.1) and `heat_effect_max_mw_m2` (20) from `data/settings.json` (tuning values; the pass legs carry `heat_peak`). One strength for all passes of a plan (the largest peak flux).
- Ship: orange hull glow through the shader's `heat` uniform (hull points along its flight, so `heat_dir` stays (1,0)); `effects/plasma_wide` additive at the nose, faded and slightly pulsing with the heat; the triangle marker turns orange. Plasma variant per hull (pointed/blunt/wide) comes with the hull choice.
- Not yet: the fireball and fragments of the burn-up (the overlay still plays the old frames).

## Step 10af - ship attitude: retrograde burns and aerobraking (untested)
- The ship flies nose first. Before a retrograde burn and before every aerobraking pass it turns tail first (engine and heat shield are at the tail), and turns back afterwards. The engine flame only shows when the ship has turned the right way round. The plasma and the hull's heat glow are on the tail while it flies tail first (assumption: the heat shield is at the tail end of the hull; flip it in `_apply_ship` if the shield is at the nose).
- `GameState.attitude_at(jd)` is a pure function of time: the turn is a smooth ramp over the turning time before the burn/pass window and back after it, so it is right at any warp. Prograde or retrograde comes from the velocity just before and after the burn (cached in `leg["prograde"]`).
- Turning rate: 180 deg/s for ships up to 5,000 kg total mass, 10 deg/s from 100,000 kg, logarithmic in between (`rotation_*` in `data/settings.json`); the example ship uses 10 deg/s, a half turn takes 18 game seconds. The ramps run before the burn window, which is played at 1 min/s, so at high warp the turn is a blink.

## Step 10ag - real time for turns, burns and passes
- `advance()` now drops the warp to real time (index 0) one half-turn time (`half_turn_days()`) before every burn or aerobraking pass window (and before the atmosphere entry), so the turn and the burn/pass are played in real time. Before, it dropped to 1 min/s at the start of the window. The player can speed up again at once. Moving into a smaller view still only drops to 1 min/s. All burn windows count now, also the departure burn (its morph is not drawn, but the ship turns and the flame shows).
- Fix: the prograde/retrograde test of a burn measures the velocity relative to the lower of the two bodies (the moon at an insertion), because in the Earth frame the capture burn at the Moon came out prograde.

## Step 10ah - turn only as long as needed
- The ship keeps the attitude of its last burn or pass (nose first / tail first). `GameState.manoeuvre_windows()` lists all burns and passes with the attitude each needs and `lead` = the half-turn time if that differs from the attitude before it, else 0. The warp drops to real time at `t0 - lead` (the start of the turn; at the window start itself if no turn is needed); `attitude_at` turns the ship over the lead time. A retrograde burn after a retrograde burn needs no turn, a prograde one after it turns back.
- A new plan starts at least a half-turn time (+3 min) after now (`_min_launch_delay`), so a relaunch right after an insertion has time to turn first.
- Test sprite: `ships/ssto_side/ssto_side` (not symmetrical). The earlier modular hull is symmetrical, so its turns could not be seen.

## Step 10ai - first burn at least 20 s away, skip stops before the turn
- A plan's first burn now starts at least 20 s (`MIN_LAUNCH_DELAY_DAYS`) after now, counted from the start of the ship's turn for it: departure time >= now + 20 s + turn time + half the burn time (`_plan_with_delay`, which re-plans from a later start if the planner returned an earlier one).
- "Skip to departure" stops 5 s before the start of the turn for the first burn (before: 2 min before the departure time, which could already be inside the burn window, so the ship's attitude changed instantly).

## Step 10aj - ship heading from one leg, test line for turning
- The ship's flight direction is now measured along the leg it is on (`leg_rel_with_offsets` of that one leg at t +- 60 s) instead of `ship_rel` at both times, which could mix two legs close to a leg change.
- Test line in the info text while the ship turns: "Turning: x% of a half turn | rate .. deg/s, a half turn takes .. s" (remove when the turning is confirmed).
- The shown attitude (`retro_shown`) now follows the plan's attitude no faster than the turning rate (in game time): aborting a launch after the ship turned makes it turn back over the turn time instead of snapping, and any other jump of the plan's attitude is smoothed the same way. The flame shows only when the shown attitude is right.

## Step 10ak - route check, lander test sprite, warp-stop reason
- Test sprite for the ship: `ships/lander` (SSTO brakes nose first, the lander tail first).
- Route check: `GameState.route_conflict(plan, parked)` samples the planned route (departure to arrival, 0.5 day steps, refined near a body) and reports the first body other than the origin, the target and their ancestors whose sphere of influence (Laplace radius `soi_radius_km`; tiny moons without a real SOI are ignored) the ship enters. `_postpone_for_route` then re-plans from later starts (1 day, growing by 1.4x each try, at most 25 tries) until the route is clear, and reports the postponement (or a warning) in the message. Not done for course changes during a flight.
- Test line "Warp stopped: <reason>" for 20 s after every automatic warp drop (atmosphere entry, a burn or pass with its leg label, a smaller view), to find unexpected stops.

## Step 10al: lock fixes, gradual burns, heat shield in percent, fly-by, top third, retracted lander (version 0.1)

- **Ship view lock** (`orbit_view.gd`): the view follows the ship only after a zoom by hand (pinch, wheel) or a double tap on the ship, never from a drag. It follows only while the ship is really in orbit around the body the camera is on (leg kind `orbit` or `aero`, not a transfer). It lets go when the view is zoomed out to less than 1/1.5 of the scale at which it began to follow, or when the ship's orbit body changes, and then centres smoothly on that body (the scale stays).
- **Burns** (`game_state.gd`): propellant of the departure and the arrival burns is taken out of the tanks while the burn runs (`_burn_fuel_gradually`), by the share of the burn window that is over; the arrival burn is shared among the propulsive capture legs by their duration. The plan is finished (arrival message, plan cleared) only after the last burn or pass of its capture legs (`_plan_finish_time`), not at the middle of the burn. The time flow is no longer dropped at the arrival. The departure can be aborted until the burn starts (`departure_done` is set at the start of the burn window).
- **Warp at the atmosphere**: reaching the outer limit of the atmosphere of an aerobraking plan only slows the time flow down to 1 min/s (`AERO_WARP_INDEX`); it drops to real time at the start of the turn for the pass. (Orbit decay passes still drop to real time.)
- **Heat shield in percent**: arrival message, status line and planner show the share of the shield capacity (used / left). `GameState.aerobraking_damage(heat, peak_g)` is the damage (health share) that the arrival uses and the planner predicts: "Expected damage: health 100% -> 62%". Heat stays in MJ/m2 internally.
- **Fly-by** (`aero_braking.gd`): if the passes leave the ship too fast, the planner looks for a burn right after the last pass (`escape_capture_dv`: set the apoapsis, raise the periapsis half an orbit later) and uses it if the tanks hold enough delta-v ("burn_assist"). Otherwise the outcome is `flyby`: no capture legs, the ship stays on its transfer orbit around the Sun and is not lost. Simplifications: the energy the passes took and the deflection are not added to the heliocentric orbit; the burn is after the pass only (not before or during it).
- **Top bar**: at most the top third of the screen (`MAX_HEIGHT_*` 0.34). A drag with a finger or the left button scrolls it, and the wheel scrolls it without zooming the map.
- **Ship sprite**: `ships/lander_parts/lander_body` (legs retracted), 22.6 px long (`SHIP_LENGTH_PX`), 30% smaller than the extended lander at 36 px.
- **Start date** (`bodies.json` `game_start`): 2047-02-23 (JD 2468764.5). The first Earth to Ceres window after it (about 2047-03-19) sends the ship through the sphere of influence of the Moon (about 1,700 km from the Moon's centre in a straight-line model), to test the route check. Press Reset game to start from it.
